# Identidade visual própria do QINBLY

## O que foi feito
- **Paleta própria** em um só lugar (`QinblyBrand` no `MainActivity.kt`): verde-jade `#008C74` (cor principal), jade profundo `#00624F`, fundo suave `#E3F5F1`, âmbar `#FFB020` (destaque) e tinta `#0B1F2A`. O azul que o app usava (`#1677F2`/`#1877F2`, quase idêntico ao de outra rede muito conhecida) saiu de **todo** o código, do `remote-config/android-ui.json` e do CSS da tela de atualização.
- **Nomes próprios:** "Clipes" (vídeos verticais) no lugar de "Reels", "Momento" no lugar de "Story". Nada no app usa nome de funcionalidade de outra marca.
- **Reações próprias:** 💚 🔥 😂 🤯 😢 👏 (em vez do conjunto clássico de outra rede).
- Para trocar a cor da marca inteira, basta mudar os valores de `QinblyBrand`.

## O que ainda é preciso para ficar 100% único (design, não código)
1. **Logo e ícone do app** criados por você ou por um designer (o projeto não traz os ícones). Não use formas parecidas com logos de outras redes.
2. **Fonte própria** (ex.: uma fonte de licença livre como Sora, Outfit ou Space Grotesk) — hoje o app usa a fonte padrão do Android.
3. **Ilustrações/estados vazios e animações** seus (as telas "nenhuma publicação" hoje usam só ícones padrão).
4. **iOS** (`ios/`) ainda não recebeu a nova paleta.

## Sobre direitos autorais e plágio (informação geral, não é aconselhamento jurídico)
- **Funções** (curtir, comentar, seguir, hashtag, mensagens) não são protegidas por direito autoral; todo app social tem.
- O que pode dar problema: **logo, nome, ícones, cores e layout idênticos** ao de outra marca, imagens/fontes sem licença e marcas registradas. Por isso a paleta, os nomes e as reações foram trocados.
- Antes de lançar, vale **pesquisar a marca "QINBLY"** no INPI (Brasil) e conferir licenças das fontes/imagens que você usar. Um advogado de propriedade intelectual pode confirmar.
