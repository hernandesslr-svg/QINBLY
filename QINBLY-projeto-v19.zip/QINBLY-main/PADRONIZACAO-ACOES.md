# Padronização das ações (curtir, comentar, repostar, salvar, enviar, seguir)

## O que mudou
- **Um só conjunto de botões** (`QinblyPostActionBar`) em todas as telas: início, vídeo em tela cheia, perfil, perfil público e visualizadores. Mesma ordem (curtir, comentar, repostar, salvar, enviar), mesmo ícone de 24dp, mesmo contador, mesma área de toque.
- **Um só botão de seguir** (`QinblyFollowButton`): "Seguir" azul preenchido, "Seguindo" com contorno. Usado no feed, vídeo em tela cheia, perfil público (versão grande) e lista de seguidores/seguindo.
- **Estado compartilhado** (`QinblyEngagement`): curtir/seguir/salvar/repostar feitos em uma tela aparecem nas outras na hora. Curtir e seguir são otimistas e voltam atrás se o servidor falhar. A contagem de curtidas não duplica depois de recarregar o feed.
- Marcações de curtida/seguindo valem por conta (trocar de conta não herda as da anterior).
- Link de compartilhamento unificado: `https://qinbly.com/post/<id>` (antes havia `qinbly.com` e `qinbly.com`). **Ajuste `QINBLY_POST_LINK_BASE` para o seu domínio real.**
- Contadores falsos "0" ao lado de repostar, salvar e enviar foram removidos (não representavam nada).
- Perfil e perfil público agora usam o diálogo de compartilhar do feed (enviar por mensagem/copiar link) em vez do compartilhamento de texto cru.

## Servidor
- A Edge Function `qinbly-api` agora devolve `likedByMe` e `isFollowing` por publicação e `followers/following/isFollowing` no perfil. **É preciso fazer o deploy de novo** para o coração e o "Seguindo" virem corretos após reabrir o app.

## Limites conhecidos
- **Repostar e salvar ainda são locais** (neste aparelho). Para virar rede social de verdade, precisam de tabela e rotas no servidor (contagem de reposts, aba "Salvos" sincronizada).
- Nada disto foi compilado nem testado em aparelho; foi conferido por leitura e balanceamento de chaves.

## Rodada 2: visualizador, card, comentários, salvar/repostar, links

- **Visualizador único** (`QinblyPostViewer`): é a tela cheia do Início (botões laterais, menu "mais", barra azul do vídeo, seguir, legenda). Agora também abre as publicações do Perfil e do Perfil público, para fotos e vídeos (fotos com galeria e toque duplo para curtir). A tela de foto de perfil continua separada, pois não é uma publicação.
- **Card de publicação único** (`QinblyPostCard`): o card do feed foi extraído e é usado no Início e nas abas Publicações/Vídeos dos dois Perfis (mesmo cabeçalho, menu, mídia, enquete, legenda e barra de ações). A aba "Fotos" continua em grade de miniaturas (padrão de rede social) e abre o mesmo visualizador.
- **Comentários únicos** (`QinblyCommentsDialog`): mesma tela, campo, emojis e teclado em todo lugar. Carrega, envia e exclui sozinho (botão de lixeira em comentários seus ou em publicações suas) e atualiza o número do botão sem recarregar o feed inteiro. Corrige também o comentário aberto a partir da tela cheia, que não carregava a lista.
- **Salvar e repostar no servidor:** novas tabelas `post_saves` e `post_reposts` (`SUPABASE/04_saves_reposts.sql`), rotas `POST /api/posts/:id/save` e `/repost`, e `savedByMe`, `repostedByMe` e `reposts` em cada publicação. O botão de repostar agora mostra o contador.
- **Link compartilhado abre a publicação:** nova rota `GET /api/posts/:id`; o app trata `https://qinbly.com/post/<id>` e `qinbly://post/<id>`, e mensagens com esse link ganham o botão "Abrir publicação".

## Para publicar
1. Rodar `SUPABASE/04_saves_reposts.sql` no SQL Editor.
2. `supabase functions deploy qinbly-api`.
3. Adicionar ao `AndroidManifest.xml` (não vem neste pacote), dentro da `MainActivity`, para links externos abrirem o app:

```xml
<intent-filter android:autoVerify="true">
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="https" android:host="qinbly.com" android:pathPrefix="/post/" />
    <data android:scheme="qinbly" android:host="post" />
</intent-filter>
```
(Para o link `https` abrir direto no app, o domínio também precisa publicar `/.well-known/assetlinks.json`.)

## Ainda sem teste real
Nada foi compilado nem executado em Android. Compile no Android Studio e valide: curtir/seguir/salvar/repostar entre telas e após fechar e reabrir o app, comentários, vídeo/foto nos três visualizadores e compartilhamento por mensagem.

## Rodada 3

- **Enquetes nos perfis:** votar agora recarrega o perfil (`reloadKey`) em `ProfilePage` e `PublicProfilePage`.
- **Foto de perfil:** um único `QinblyPhotoViewer` (zoom por pinça, toque duplo, controles, menu salvar/compartilhar e, no perfil público, denunciar) nos dois perfis. As telas de edição de perfil continuam separadas.
- **Meus salvos:** nova rota `GET /api/me/saved` (precisa publicar `qinbly-api` de novo), `QinblyApi.getSavedPosts` e a aba "Salvos" do seu perfil com os cards padrão. Ao remover o salvo, o item some da lista na hora.

## Rodada 4 — cara de rede social

- **Hashtags e menções:** `#tag` e `@usuario` nas legendas viram links (`QinblyRichText`). Hashtag abre a tela da tag (`QinblyTagHost`) com os cards padrão; menção abre o perfil.
- **Explorar:** a busca agora mostra "Em alta" (hashtags mais usadas) e "Pessoas para seguir" quando está vazia; digitar `#algo` abre a hashtag.
- **Feed:** o filtro "Tendências" agora ordena por engajamento (antes não fazia nada). "Perto de mim" foi removido porque não existe localização no app.
- **Recuperar senha:** link "Esqueci minha senha" na tela de login, via `POST /api/auth/forgot` (o e-mail é enviado pelo Supabase Auth).
- **Servidor novo:** `/api/hashtags/trending`, `/api/hashtags/:tag`, `/api/users/suggested`, `/api/auth/forgot` — é preciso publicar `qinbly-api` de novo.
- **Para o e-mail de recuperação funcionar:** configure em Supabase → Authentication → URL Configuration a URL de redirecionamento e o template do e-mail.

## Rodada 5 — varredura

- **Menu "⋮" unificado:** havia duas cópias idênticas do menu da publicação dentro de `QinblyPostCard`; agora é um só (`QinblyPostMenu`).
- **Dono da publicação:** Editar legenda (novo, `PATCH /api/posts/:id`), Copiar link (antes só aparecia para os outros) e Excluir com confirmação.
- **Servidor:** publicar `qinbly-api` de novo.

## Rodada 6 — recursos sociais adicionais

- **Comentários:** respostas em fio (um nível), curtir comentário com contador, "Respondendo a @…", horário real.
- **Reações:** segurar o botão curtir abre 💚 🔥 😂 🤯 😢 👏; tocar de novo na mesma remove. O emoji aparece no botão.
- **Fixar (até 3) e arquivar:** no menu ⋮ das suas publicações; fixadas ficam no topo do perfil com 📌; nova aba "Arquivo" (só você vê).
- **Menções e respostas notificam** (`mention`, `reply`). Notificações novas também aparecem como notificação do sistema (enquanto o app está aberto/em memória; push com o app fechado exige Firebase — veja abaixo).
- **Clipes:** novo filtro "Clipes" no feed abre os vídeos em tela cheia, um por vez, deslizando na vertical.
- **Servidor:** publicar `qinbly-api` e rodar `SUPABASE/05_social_features.sql`.
- **Projeto:** `SUPABASE/00_base_schema.sql` (só banco novo), `SUPABASE/README.md` e `android-scaffold/` (manifest, gradle, res). Faltam do projeto original: as 25 imagens `qinbly_frame_*` e os ícones.

### Push com o app fechado (não incluído)
Precisa de um projeto Firebase seu: `google-services.json`, dependência `firebase-messaging`, um serviço que receba o token, uma tabela `device_tokens` e a função enviando via FCM. Sem a sua conta Firebase não dá para criar de forma funcional.

## Rodada 7 — "Seguir/Seguindo" igual em todas as telas

- **Causa:** as listas de pessoas (busca, "Pessoas para seguir", seguidores/seguindo) não recebiam do servidor se você já segue a pessoa (assumiam "não"), e a lista do perfil público nem tinha botão.
- **Correção:** o servidor agora devolve `isFollowing` em busca, seguidores e seguindo; o app aprende esse estado de qualquer resposta do servidor (feed, hashtag, salvos, busca, listas, perfis) em `QinblyEngagement.learnFollows`, e todas as telas usam o mesmo botão (`QinblyFollowButton`) lendo o mesmo estado. As listas de seguidores/seguindo (do seu perfil e dos perfis públicos) agora mostram avatar e botão de seguir.
- Publicar `qinbly-api` de novo.

## Rodada 8 — vídeo no feed

- Removido o botão de tela cheia que ficava sobre o vídeo (tocar no vídeo, fora do botão de play, continua abrindo o visualizador).
- Laterais de vídeos verticais agora usam o próprio vídeo desfocado como fundo (Android 12+; abaixo disso fica fundo preto), sem a faixa cinza.
- Barra de progresso fina e botão de som enquanto o vídeo toca.

## Rodada 9 — perfil sem "piscar" ao trocar de aba

- O seu perfil guardava tudo só dentro da tela; ao sair e voltar, a tela recomeçava vazia (foto padrão, contadores zerados, carregando) até a rede responder.
- Agora o último perfil carregado fica em memória (`QinblyCache.own`) e um resumo (foto, capa, contadores, moldura) também no aparelho. Ao voltar para a aba, a tela já abre com tudo e só atualiza por trás. É apagado ao sair/trocar de conta.

## Rodada 10 — fotos de perfil sem atraso em TODAS as telas

- **Causa raiz:** `QiblyAccountAvatar` (usado no feed, comentários, listas, mensagens…) baixava o perfil completo da pessoa toda vez que aparecia e começava mostrando a silhueta; por isso a foto "aparecia depois".
- **Correção:** `QinblyAvatarCache` — cache único (memória reativa + aparelho) de foto e moldura. Qualquer tela já abre com a foto certa; o perfil só é buscado se o cache tiver mais de 10 min e uma vez por pessoa (não por cartão). Trocar a foto de perfil invalida o cache; sair/trocar de conta limpa tudo.
- **Mensagens:** a lista de conversas também fica em cache (`QinblyCache.inbox`) e abre na hora.
- **Removido:** conversas de demonstração falsas (Carol, Júlia, Marina, Ana) que apareciam na lista de mensagens.

## Rodada 11 — uma única foto de perfil em todo o app

- **Causa:** cada perfil tem duas imagens no banco (`avatar_path` e `cover_path`). O cabeçalho do perfil lia a de capa; publicações, listas, busca, mensagens e notificações liam a de avatar. Quando as duas divergiam (fotos antigas, ou um upload que falhou), apareciam fotos diferentes.
- **Correção (servidor, vale para todos os usuários):** `canonicalizePhotos` em `qinbly-api` — toda resposta que traz perfil passa a usar a foto enquadrada no editor (`cover_path`) também como avatar. Não é preciso migrar dados.
- **Ao trocar a foto:** o app descarta o cache de fotos e recarrega; outras pessoas passam a ver a nova foto em até ~10 minutos (validade do cache de avatar) ou ao reabrir o app.
- Publicar `qinbly-api` de novo.

## Rodada 12 — só uma foto de perfil (a do cabeçalho)

- O editor de foto deixou de enviar uma segunda imagem de avatar; o servidor grava a mesma foto em `cover_path` e `avatar_path` (nunca divergem) e continua devolvendo a foto do cabeçalho como avatar em todas as respostas.
- Rodar `SUPABASE/06_single_profile_photo.sql` uma vez: copia a foto do cabeçalho para onde as duas colunas estavam diferentes (corrige também a lista de bloqueados).
- Publicar `qinbly-api` de novo.
