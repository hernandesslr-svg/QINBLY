import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
// Injetada automaticamente pelo Supabase nas Edge Functions. Usada SOMENTE no servidor, para excluir a conta.
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "GET, POST, PATCH, PUT, DELETE, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
};
const reply = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: corsHeaders });
// Traduz erros das funções SQL de comunidade em respostas HTTP claras.
const rpcFail = (e: unknown) => {
  const m = e instanceof Error ? e.message : String(e);
  if (m.includes("not_found")) return reply({ error: "Conteúdo ou usuário não encontrado." }, 404);
  if (m.includes("cannot_") || m.includes("invalid_") || m.includes("23514") || m.includes("22023")) return reply({ error: "Pedido inválido." }, 400);
  throw e;
};
const serviceFetch = (path: string, init: RequestInit = {}) => fetch(`${SUPABASE_URL}${path}`, {
  ...init,
  headers: { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json", ...(init.headers || {}) },
});
const listStorageObjects = async (bucket: string, prefix: string): Promise<string[]> => {
  const out: string[] = [];
  for (let offset = 0; ; offset += 1000) {
    const r = await serviceFetch(`/storage/v1/object/list/${bucket}`, { method: "POST", body: JSON.stringify({ prefix, limit: 1000, offset }) });
    if (!r.ok) throw new Error(`storage_list_failed:${bucket}:${r.status}`);
    const items: any[] = await r.json();
    for (const it of items) {
      if (it.id) out.push(`${prefix}${it.name}`);
      else out.push(...await listStorageObjects(bucket, `${prefix}${it.name}/`)); // "pasta"
    }
    if (items.length < 1000) break;
  }
  return out;
};
const purgeUserStorage = async (userId: string) => {
  for (const bucket of ["post-media", "private-documents"]) {
    const paths = await listStorageObjects(bucket, `${userId}/`);
    for (let i = 0; i < paths.length; i += 100) {
      const r = await serviceFetch(`/storage/v1/object/${bucket}`, { method: "DELETE", body: JSON.stringify({ prefixes: paths.slice(i, i + 100) }) });
      if (!r.ok) throw new Error(`storage_delete_failed:${bucket}:${r.status}`);
    }
  }
};
// Conta linhas sem baixá-las (Prefer: count=exact + Range 0-0 -> Content-Range "0-0/N").
const countRows = async (path: string, token?: string): Promise<number> => {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { headers: { apikey: ANON_KEY, Authorization: `Bearer ${token || ANON_KEY}`, Prefer: "count=exact", Range: "0-0" } });
  const total = Number((res.headers.get("content-range") || "").split("/")[1]);
  return Number.isFinite(total) ? total : 0;
};
// Cada perfil tem duas imagens (avatar_path e cover_path). A foto de perfil oficial é a que a pessoa enquadrou
// no editor (cover_path), então toda resposta passa a usá-la também como avatar: assim a MESMA foto aparece no
// perfil, nas publicações, nas listas, na busca, nas mensagens e nas notificações, para todos os usuários.
const canonicalizePhotos = (value: any): any => {
  if (Array.isArray(value)) { value.forEach(canonicalizePhotos); return value; }
  if (value && typeof value === "object") {
    if (typeof value.cover_path === "string" && value.cover_path && "avatar_path" in value) value.avatar_path = value.cover_path;
    for (const key of Object.keys(value)) { const child = value[key]; if (child && typeof child === "object") canonicalizePhotos(child); }
  }
  return value;
};
const api = async (path: string, token?: string, init: RequestInit = {}) => {
  const headers = new Headers(init.headers || {});
  headers.set("apikey", ANON_KEY);
  headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);
  else headers.set("Authorization", `Bearer ${ANON_KEY}`);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { ...init, headers });
  const body = await res.text();
  if (!res.ok) throw new Error(body || `Supabase REST HTTP ${res.status}`);
  return body ? canonicalizePhotos(JSON.parse(body)) : null;
};
const authUser = async (token: string) => {
  const r = await fetch(`${SUPABASE_URL}/auth/v1/user`, { headers: { apikey: ANON_KEY, Authorization: `Bearer ${token}` } });
  if (!r.ok) return null;
  return await r.json();
};
const tokenOf = (req: Request) => (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
const safeObjectPath = (value: string) => value && !value.startsWith("/") && !value.includes("..") && !value.includes("\\") && value.split("/").every(part => /^[a-zA-Z0-9._-]+$/.test(part));
const getStoredObjectInfo = async (objectPath: string, token: string) => {
  if (!safeObjectPath(objectPath)) return null;
  const encodedPath = objectPath.split("/").map(encodeURIComponent).join("/");
  const response = await fetch(`${SUPABASE_URL}/storage/v1/object/info/post-media/${encodedPath}`, {
    headers: { apikey: ANON_KEY, Authorization: `Bearer ${token}` }
  });
  if (!response.ok) return null;
  return await response.json().catch(() => null);
};
const objectMimeType = (info: any, objectPath = "") => {
  const reported = String(
    info?.metadata?.mimetype ||
    info?.metadata?.contentType ||
    info?.contentType ||
    info?.mimetype ||
    info?.mimeType ||
    ""
  ).toLowerCase().split(";")[0].trim();
  if (reported.startsWith("image/")) return reported;
  // O endpoint Storage /object/info nem sempre retorna o MIME em todos os formatos
  // de resposta. O nome do arquivo é gerado pelo backend a partir do MIME validado
  // em /api/files/upload-url, então a extensão é um fallback seguro para a validação.
  const extension = objectPath.toLowerCase().split("?")[0].split(".").pop() || "";
  const extensionMime: Record<string, string> = {
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    webp: "image/webp",
    gif: "image/gif",
  };
  return reported || extensionMime[extension] || "";
};
const profileById = async (id: string, token: string, preferredUsername = "") => {
  const rows = await api(`profiles?id=eq.${encodeURIComponent(id)}&select=*`, token);
  if (!rows?.length) {
    const generated = `user_${id.replaceAll("-", "").slice(0,12)}`;
    const username = preferredUsername.trim().toLowerCase().replace(/[^a-z0-9_.]/g, "").slice(0,30) || generated;
    await api("profiles", token, { method: "POST", headers: { Prefer: "resolution=ignore-duplicates,return=minimal" }, body: JSON.stringify([{ id, username, display_name: preferredUsername.trim(), bio: "" }]) });
    const fresh = await api(`profiles?id=eq.${encodeURIComponent(id)}&select=*`, token);
    return fresh?.[0] || { id, username, display_name: preferredUsername.trim(), bio: "" };
  }
  return rows[0];
};
const profileDto = (p: any) => ({ id:p.id, username:p.username, email:p.email || "", displayName:p.display_name || "", bio:p.bio || "", avatarUrl:p.avatar_path ? (p.avatar_path.startsWith("http") ? p.avatar_path : `${SUPABASE_URL}/storage/v1/object/public/post-media/${p.avatar_path}`) : "", coverUrl:p.cover_path ? (p.cover_path.startsWith("http") ? p.cover_path : `${SUPABASE_URL}/storage/v1/object/public/post-media/${p.cover_path}`) : null, originalCoverUrl:p.cover_original_path ? (p.cover_original_path.startsWith("http") ? p.cover_original_path : `${SUPABASE_URL}/storage/v1/object/public/post-media/${p.cover_original_path}`) : null, verified:!!p.is_verified, createdAt:p.created_at });
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const url = new URL(req.url);
    // Supabase gateway versions may expose the function slug in the pathname differently.
    // Normalize to the API route so /api/auth/google cannot fall through into the authenticated profile guard.
    const apiRouteIndex = url.pathname.indexOf("/api/");
    const normalizedPath = apiRouteIndex >= 0 ? url.pathname.slice(apiRouteIndex) : url.pathname.replace(/^\/functions\/v1\/qinbly-api/, "");
    const path = normalizedPath.replace(/\/$/, "") || "/";
    const token = tokenOf(req);
    // Leitor opcional: com token válido, as rotas públicas passam a consultar COMO o usuário (RLS usa auth.uid()),
    // o que aplica bloqueios e permite devolver likedByMe/isFollowing. Token ausente/inválido = leitura anônima.
    let viewerPromise: Promise<any> | null = null;
    const viewer = () => (viewerPromise ??= token ? authUser(token) : Promise.resolve(null));
    const body = ["POST","PATCH","PUT","DELETE"].includes(req.method) ? await req.json().catch(() => ({})) : {};
    // Accept both the legacy custom bearer and a valid Supabase session only after checking Auth.
    // No anonymous or fabricated token is ever treated as an authenticated user.
    if (req.method === "POST" && path === "/api/auth/google") {
      const idToken = String(body.idToken || body.id_token || "");
      if (!idToken) return reply({error:"Credencial Google ausente."},400);
      const r = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=id_token`, { method:"POST", headers:{apikey:ANON_KEY,"Content-Type":"application/json"}, body:JSON.stringify({provider:"google", id_token:idToken}) });
      const data = await r.json();
      if (!r.ok) {
        console.error("Google Auth rejected token:", JSON.stringify({status:r.status,error:data.error,code:data.code,message:data.msg || data.message || data.error_description || data.error_description}));
        const detail = data.error_description || data.msg || data.message || data.error || data.code;
        // Surface Supabase's actual rejection reason to the app; do not replace it with a generic OAuth hint.
        const diagnostic = [detail, data.code && data.code !== detail ? `Código: ${data.code}` : ""].filter(Boolean).join(" — ");
        return reply({
          error: diagnostic || `O Supabase recusou o token do Google (HTTP ${r.status}).`,
          code: data.code || data.error || "google_auth_failed"
        }, r.status);
      }
      const p = await profileById(data.user.id, data.access_token, String(data.user.user_metadata?.username || data.user.user_metadata?.full_name || data.user.email?.split("@")[0] || ""));
      return reply({token:data.access_token, refreshToken:data.refresh_token, user:{...profileDto({...p, email:data.user.email}), username:p.username || `user_${data.user.id.replaceAll("-","").slice(0,12)}`}});
    }
    // Refresh a Supabase session using its refresh token; never accept an access token as a refresh credential.
    if (req.method === "POST" && path === "/api/auth/refresh") {
      const refreshToken = String(body.refreshToken || body.refresh_token || "").trim();
      if (!refreshToken || refreshToken.length > 4096) return reply({error:"Sessão vencida. Entre novamente na sua conta."},401);
      const refreshed = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method:"POST",
        headers:{apikey:ANON_KEY,"Content-Type":"application/json"},
        body:JSON.stringify({refresh_token:refreshToken})
      });
      const data = await refreshed.json().catch(() => ({}));
      if (!refreshed.ok || !data.access_token || !data.refresh_token || !data.user?.id) {
        return reply({error:"Não foi possível renovar a sessão. Entre novamente na sua conta.", code:data.code || data.error || "refresh_failed"},401);
      }
      const p = await profileById(data.user.id,data.access_token,String(data.user.user_metadata?.username || data.user.email?.split("@")[0] || ""));
      return reply({token:data.access_token,refreshToken:data.refresh_token,user:profileDto({...p,email:data.user.email})});
    }
    if (req.method === "POST" && path === "/api/auth/forgot") {
      const email = String(body.email || "").trim().toLowerCase();
      if (!email.includes("@") || email.length > 200) return reply({ error: "Digite um e-mail válido." }, 400);
      await fetch(`${SUPABASE_URL}/auth/v1/recover`, { method: "POST", headers: { apikey: ANON_KEY, "Content-Type": "application/json" }, body: JSON.stringify({ email }) }).catch(() => null);
      // Resposta sempre igual para não revelar quais e-mails têm conta.
      return reply({ ok: true, message: "Se esse e-mail tiver uma conta, enviamos o link para criar uma nova senha." });
    }
    if (req.method === "POST" && (path === "/api/auth/login" || path === "/api/auth/register")) {
      const register = path.endsWith("register");
      const r = await fetch(`${SUPABASE_URL}/auth/v1/${register ? "signup" : "token?grant_type=password"}`, {method:"POST",headers:{apikey:ANON_KEY,"Content-Type":"application/json"},body:JSON.stringify({email:String(body.email||"").trim().toLowerCase(),password:String(body.password||""), ...(register?{data:{username:String(body.username||"").trim().toLowerCase()}}:{})})});
      const data = await r.json();
      if (!r.ok) return reply({error:data.msg || data.message || data.error_description || "Autenticação recusada."},r.status);
      if (!data.access_token) return reply({error:"Confirme o e-mail para concluir o cadastro."},202);
      const p = await profileById(data.user.id,data.access_token,String(data.user.user_metadata?.username || body.username || data.user.email?.split("@")[0] || ""));
      return reply({token:data.access_token,refreshToken:data.refresh_token,user:profileDto({...p,email:data.user.email})},register?201:200);
    }
    const buildPostDtos = async (posts:any[], viewerUser:any, vt?:string) => {
      const ids=(posts||[]).map((p:any)=>p.id).filter(Boolean);
      const idFilter=ids.length?ids.join(","):"00000000-0000-0000-0000-000000000000";
      const authorIds=[...new Set(posts.map((p:any)=>p.user_id).filter(Boolean))].join(",")||"00000000-0000-0000-0000-000000000000";
      const [likeRows,commentRows,myLikeRows,myFollowRows,repostRows,mySaveRows,myRepostRows]=ids.length?await Promise.all([
        api(`post_likes?post_id=in.(${idFilter})&select=post_id,reaction`,vt).catch(()=>api(`post_likes?post_id=in.(${idFilter})&select=post_id`,vt)),
        api(`comments?post_id=in.(${idFilter})&select=post_id`,vt),
        viewerUser?.id?api(`post_likes?user_id=eq.${viewerUser.id}&post_id=in.(${idFilter})&select=post_id,reaction`,vt).catch(()=>api(`post_likes?user_id=eq.${viewerUser.id}&post_id=in.(${idFilter})&select=post_id`,vt)):Promise.resolve([]),
        viewerUser?.id?api(`follows?follower_id=eq.${viewerUser.id}&following_id=in.(${authorIds})&select=following_id`,vt):Promise.resolve([]),
        api(`post_reposts?post_id=in.(${idFilter})&select=post_id`,vt).catch(()=>[]),
        viewerUser?.id?api(`post_saves?user_id=eq.${viewerUser.id}&post_id=in.(${idFilter})&select=post_id`,vt).catch(()=>[]):Promise.resolve([]),
        viewerUser?.id?api(`post_reposts?user_id=eq.${viewerUser.id}&post_id=in.(${idFilter})&select=post_id`,vt).catch(()=>[]):Promise.resolve([])
      ]):[[],[],[],[],[],[],[]];
      const repostCounts=new Map<string,number>();
      for(const row of repostRows||[])repostCounts.set(row.post_id,(repostCounts.get(row.post_id)||0)+1);
      const mySaves=new Set<string>((mySaveRows||[]).map((r:any)=>r.post_id));
      const myReposts=new Set<string>((myRepostRows||[]).map((r:any)=>r.post_id));
      const myLikes=new Set<string>((myLikeRows||[]).map((r:any)=>r.post_id));
      const myFollows=new Set<string>((myFollowRows||[]).map((r:any)=>r.following_id));
      const likeCounts=new Map<string,number>();
      const commentCounts=new Map<string,number>();
      for(const row of likeRows||[])likeCounts.set(row.post_id,(likeCounts.get(row.post_id)||0)+1);
      const reactionCounts=new Map<string,Map<string,number>>();
      for(const row of likeRows||[]){
        const r=row.reaction||"like"; if(r==="like")continue;
        const m=reactionCounts.get(row.post_id)||new Map<string,number>(); m.set(r,(m.get(r)||0)+1); reactionCounts.set(row.post_id,m);
      }
      const myReactionMap=new Map<string,string>();
      for(const row of myLikeRows||[])myReactionMap.set(row.post_id,row.reaction||"like");
      for(const row of commentRows||[])commentCounts.set(row.post_id,(commentCounts.get(row.post_id)||0)+1);
      return (posts||[]).map((p:any)=>({
        id:p.id,
        createdAt:p.created_at,
        caption:p.caption,
        mediaUrl:p.media_path?.startsWith("http")?p.media_path:(p.media_path?`${SUPABASE_URL}/storage/v1/object/public/post-media/${p.media_path}`:""),
        mediaType:p.media_type,
        author:{
          id:p.profiles?.id,
          username:p.profiles?.username,
          displayName:p.profiles?.display_name,
          avatarUrl:p.profiles?.avatar_path?(p.profiles.avatar_path.startsWith("http")?p.profiles.avatar_path:`${SUPABASE_URL}/storage/v1/object/public/post-media/${p.profiles.avatar_path}`):""
        },
        likes:likeCounts.get(p.id)||0,
        comments:commentCounts.get(p.id)||0,
        likedByMe:myLikes.has(p.id),
        savedByMe:mySaves.has(p.id),
        repostedByMe:myReposts.has(p.id),
        reposts:repostCounts.get(p.id)||0,
        isFollowing:myFollows.has(p.user_id),
        myReaction:myReactionMap.get(p.id)||"",
        reactions:[...(reactionCounts.get(p.id)?.entries()||[])].sort((a,b)=>b[1]-a[1]).slice(0,3).map(([e])=>e),
        pinned:!!p.pinned_at,
        archived:p.visibility==="archived"
      }));
    };
    const buildCommentDtos = async (rows: any[], viewerUser: any, vt?: string) => {
      const ids = (rows || []).map((c: any) => c.id);
      const idf = ids.length ? ids.join(",") : "00000000-0000-0000-0000-000000000000";
      const [likeRows, myRows] = ids.length ? await Promise.all([
        api(`comment_likes?comment_id=in.(${idf})&select=comment_id`, vt).catch(() => []),
        viewerUser?.id ? api(`comment_likes?user_id=eq.${viewerUser.id}&comment_id=in.(${idf})&select=comment_id`, vt).catch(() => []) : Promise.resolve([]),
      ]) : [[], []];
      const counts = new Map<string, number>();
      for (const r of likeRows || []) counts.set(r.comment_id, (counts.get(r.comment_id) || 0) + 1);
      const mine = new Set<string>((myRows || []).map((r: any) => r.comment_id));
      return (rows || []).map((c: any) => ({
        id: c.id, body: c.body, createdAt: c.created_at, parentId: c.parent_id || "",
        likes: counts.get(c.id) || 0, likedByMe: mine.has(c.id),
        author: { username: c.profiles?.username, displayName: c.profiles?.display_name },
      }));
    };
    // Marca em listas de pessoas quem o visitante já segue (a fonte da verdade é o servidor).
    const withFollowFlag = async (rows: any[], viewerUser: any, vt?: string) => {
      const ids = (rows || []).map((p: any) => p.id).filter(Boolean);
      let mine = new Set<string>();
      if (viewerUser?.id && ids.length) {
        const f = await api(`follows?follower_id=eq.${viewerUser.id}&following_id=in.(${ids.join(",")})&select=following_id`, vt).catch(() => []);
        mine = new Set<string>((f || []).map((x: any) => x.following_id));
      }
      return (rows || []).map((p: any) => ({ ...profileDto(p), isFollowing: mine.has(p.id) }));
    };
    // Public read routes are allowed before authentication; database RLS still applies.
    if (req.method==="GET" && path==="/api/posts") {
      const viewerUser=await viewer(); const vt=viewerUser?.id?token:undefined;
      const posts=(await api("posts?select=*,profiles!posts_user_id_fkey(id,username,display_name,avatar_path,cover_path)&visibility=eq.public&order=created_at.desc&limit=30",vt) || []).filter((p:any)=>p.media_type!=="poll" || (p.poll_expires_at && Date.parse(p.poll_expires_at)>Date.now()));
      return reply({posts:await buildPostDtos(posts,viewerUser,vt)});
    }
    const singlePostMatch=path.match(/^\/api\/posts\/([0-9a-f-]{36})$/i);
    if (req.method==="GET" && singlePostMatch) {
      const viewerUser=await viewer(); const vt=viewerUser?.id?token:undefined;
      const rows=await api(`posts?id=eq.${singlePostMatch[1]}&visibility=eq.public&select=*,profiles!posts_user_id_fkey(id,username,display_name,avatar_path,cover_path)&limit=1`,vt);
      if(!rows?.length) return reply({error:"Publicação não encontrada."},404);
      return reply({post:(await buildPostDtos(rows,viewerUser,vt))[0]});
    }
    if (req.method==="GET" && path.startsWith("/api/posts/") && path.endsWith("/comments")) {
      const postId=path.split("/")[3];
      const viewerUser=await viewer();
      const vt=viewerUser?.id?token:undefined;
      const rows=await api(`comments?post_id=eq.${postId}&select=*,profiles(username,display_name)&order=created_at.asc`,vt);
      return reply({comments:await buildCommentDtos(rows||[],viewerUser,vt)});
    }
    if (req.method==="GET" && path.startsWith("/api/users/") && !path.includes("/me") && !path.endsWith("/followers") && !path.endsWith("/following")) {
      const name=decodeURIComponent(path.split("/")[2]||"").replace(/^@/,"").toLowerCase();
      const viewerUser=await viewer(); const vt=viewerUser?.id?token:undefined;
      const rows=await api(`profiles?username=eq.${encodeURIComponent(name)}&select=*`,vt);
      if(!rows?.[0])return reply({error:"Perfil não encontrado."},404);
      const ownProfile=!!viewerUser?.id&&viewerUser.id===rows[0].id;
      // Uma única ida ao servidor devolve perfil + contadores + publicações (em paralelo), em vez de duas chamadas em série.
      const [followerCount,followingCount,mine,profilePostRows]=await Promise.all([
        countRows(`follows?following_id=eq.${rows[0].id}&select=follower_id`,vt),
        countRows(`follows?follower_id=eq.${rows[0].id}&select=following_id`,vt),
        viewerUser?.id?api(`follows?follower_id=eq.${viewerUser.id}&following_id=eq.${rows[0].id}&select=follower_id`,vt):Promise.resolve([]),
        api(`posts?user_id=eq.${rows[0].id}${ownProfile?"":"&visibility=eq.public"}&select=*,profiles!posts_user_id_fkey(id,username,display_name,avatar_path,cover_path)&order=created_at.desc&limit=60`,vt).catch(()=>[])
      ]);
      const sortedProfileRows=[...(profilePostRows||[])].sort((a:any,b:any)=>(b.pinned_at?1:0)-(a.pinned_at?1:0)||String(b.pinned_at||"").localeCompare(String(a.pinned_at||""))||String(b.created_at).localeCompare(String(a.created_at)));
      const profilePosts=await buildPostDtos(sortedProfileRows,viewerUser,vt);
      return reply({user:{...profileDto(rows[0]),followers:followerCount,following:followingCount,isFollowing:!!mine?.length},posts:profilePosts});
    }
    if (req.method==="GET" && path==="/api/hashtags/trending") {
      const rows=await api(`posts?visibility=eq.public&caption=like.*%23*&select=caption&order=created_at.desc&limit=400`).catch(()=>[]);
      const counts=new Map<string,number>();
      for(const r of rows||[]){
        const seen=new Set<string>();
        for(const m of String(r.caption||"").matchAll(/#([\p{L}\p{N}_]{2,30})/gu)){
          const t=m[1].toLowerCase(); if(seen.has(t))continue; seen.add(t); counts.set(t,(counts.get(t)||0)+1);
        }
      }
      const tags=[...counts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,12).map(([tag,posts])=>({tag,posts}));
      return reply({tags});
    }
    if (req.method==="GET" && path.startsWith("/api/hashtags/")) {
      const tag=decodeURIComponent(path.split("/")[3]||"").replace(/^#/,"").toLowerCase();
      if(!/^[\p{L}\p{N}_]{2,30}$/u.test(tag)) return reply({error:"Hashtag inválida."},400);
      const viewerUser=await viewer(); const vt=viewerUser?.id?token:undefined;
      const rows=await api(`posts?visibility=eq.public&caption=ilike.*%23${encodeURIComponent(tag)}*&select=*,profiles!posts_user_id_fkey(id,username,display_name,avatar_path,cover_path)&order=created_at.desc&limit=120`,vt).catch(()=>[]);
      const exact=new RegExp(`#${tag}(?![\\p{L}\\p{N}_])`,"iu");
      const matching=(rows||[]).filter((p:any)=>exact.test(String(p.caption||""))).slice(0,60);
      return reply({tag,posts:await buildPostDtos(matching,viewerUser,vt)});
    }
    if (req.method==="GET" && path==="/api/users/suggested") {
      const viewerUser=await viewer(); const vt=viewerUser?.id?token:undefined;
      const rows=await api(`profiles?select=id,username,display_name,bio,avatar_path,cover_path,is_verified,created_at&order=created_at.desc&limit=60`,vt).catch(()=>[]);
      let followed=new Set<string>();
      if(viewerUser?.id){
        const f=await api(`follows?follower_id=eq.${viewerUser.id}&select=following_id`,vt).catch(()=>[]);
        followed=new Set<string>((f||[]).map((x:any)=>x.following_id));
      }
      const picks=(rows||[]).filter((p:any)=>p.username&&p.id!==viewerUser?.id&&!followed.has(p.id)).sort((a:any,b:any)=>(b.is_verified?1:0)-(a.is_verified?1:0)).slice(0,12);
      return reply({users:picks.map((p:any)=>({...profileDto(p),isFollowing:false}))});
    }
    if (req.method==="GET" && (path==="/api/users/search" || path==="/api/search")) {
      const q=url.searchParams.get("q")||"";
      const viewerUser=await viewer();
      const rows=await api(`profiles?or=(username.ilike.*${encodeURIComponent(q)}*,display_name.ilike.*${encodeURIComponent(q)}*)&select=id,username,display_name,bio,avatar_path,cover_path,is_verified&limit=30`,viewerUser?.id?token:undefined);
      return reply({users:await withFollowFlag(rows||[],viewerUser,viewerUser?.id?token:undefined)});
    }
    if (!token) return reply({error:"Sua sessão expirou ou não é mais válida. Entre novamente com o Google para continuar."},401);
    const user = await authUser(token);
    // Avisa quem foi marcado com @usuario (falhas aqui nunca derrubam a publicação/comentário).
    const notifyMentions = async (text: string, entityId: string, kind = "mention", onlyIds?: string[]) => {
      try {
        let targets: string[] = onlyIds || [];
        if (!onlyIds) {
          const names = [...new Set([...String(text).matchAll(/@([A-Za-z0-9_.]{3,24})/g)].map((m) => m[1].toLowerCase().replace(/\.$/, "")))].slice(0, 10);
          if (!names.length) return;
          const found = await serviceFetch(`/rest/v1/profiles?username=in.(${names.map((n) => encodeURIComponent(n)).join(",")})&select=id`).then((r) => r.json());
          targets = (Array.isArray(found) ? found : []).map((r: any) => r.id);
        }
        targets = targets.filter((id) => id && id !== user.id);
        if (!targets.length) return;
        await serviceFetch(`/rest/v1/notifications`, { method: "POST", body: JSON.stringify(targets.map((rid) => ({ recipient_id: rid, actor_id: user.id, kind, entity_id: entityId }))) });
      } catch (_) { /* notificação é opcional */ }
    };
    if (!user?.id) return reply({error:"Sua sessão expirou ou não é mais válida. Entre novamente com o Google para continuar."},401);
    const me = () => profileById(user.id,token);
    // (movida para depois da autenticação: antes usava `user` antes da declaração e sempre falhava com erro 500)
    if(req.method==="POST"&&/^\/api\/users\/[0-9a-f-]+\/follow$/i.test(path)){
      const id=path.split("/")[3];
      if(id===user.id)return reply({error:"Você não pode seguir a própria conta."},400);
      const target=(await api(`profiles?id=eq.${id}&select=id`,token))?.[0];
      if(!target)return reply({error:"Perfil não encontrado."},404);
      const existing=await api(`follows?follower_id=eq.${user.id}&following_id=eq.${id}&select=follower_id`,token);
      if(existing?.length){await api(`follows?follower_id=eq.${user.id}&following_id=eq.${id}`,token,{method:"DELETE"});return reply({following:false});}
      await api("follows",token,{method:"POST",body:JSON.stringify([{follower_id:user.id,following_id:id}])});return reply({following:true});
    }
    if (req.method === "GET" && path === "/api/auth/me") return reply({user:profileDto({...await me(),email:user.email})});
    if (req.method === "PATCH" && path === "/api/users/me") {
      const payload:any = {};
      if (body.username) payload.username=String(body.username).trim().toLowerCase();
      if (body.displayName !== undefined) payload.display_name=String(body.displayName).trim();
      if (body.bio !== undefined) payload.bio=String(body.bio).trim();
      payload.updated_at=new Date().toISOString();
      const rows=await api(`profiles?id=eq.${user.id}&select=*`,token,{method:"PATCH",headers:{Prefer:"return=representation"},body:JSON.stringify(payload)});
      return reply({user:profileDto({...rows?.[0],email:user.email})});
    }
    // ===== Comunidade: bloquear, denunciar, apagar comentário, excluir conta =====
    const blockMatch = path.match(/^\/api\/users\/([0-9a-f-]{36})\/block$/i);
    if (req.method === "POST" && blockMatch) {
      try {
        const blocked = await api("rpc/toggle_block", token, { method: "POST", body: JSON.stringify({ target: blockMatch[1] }) });
        return reply({ blocked: blocked === true });
      } catch (e) { return rpcFail(e); }
    }
    if (req.method === "GET" && path === "/api/users/me/blocks") {
      const rows = await api("rpc/list_my_blocks", token, { method: "POST", body: "{}" });
      return reply({ blocks: (rows || []).map((b: any) => ({ id: b.id, username: b.username, displayName: b.display_name || "", avatarUrl: b.avatar_path ? (b.avatar_path.startsWith("http") ? b.avatar_path : `${SUPABASE_URL}/storage/v1/object/public/post-media/${b.avatar_path}`) : "", blockedAt: b.blocked_at })) });
    }
    if (req.method === "POST" && path === "/api/reports") {
      try {
        await api("rpc/report_content", token, { method: "POST", body: JSON.stringify({ p_type: String(body.targetType || ""), p_target: String(body.targetId || ""), p_reason: String(body.reason || ""), p_details: String(body.details || "").slice(0, 500) }) });
        return reply({ ok: true }, 201);
      } catch (e) { return rpcFail(e); }
    }
    const commentLike = path.match(/^\/api\/comments\/([0-9a-f-]{36})\/like$/i);
    if (req.method === "POST" && commentLike) {
      const cid = commentLike[1];
      const had = await api(`comment_likes?comment_id=eq.${cid}&user_id=eq.${user.id}&select=user_id`, token);
      if (had?.length) { await api(`comment_likes?comment_id=eq.${cid}&user_id=eq.${user.id}`, token, { method: "DELETE" }); return reply({ liked: false }); }
      await api("comment_likes", token, { method: "POST", body: JSON.stringify([{ comment_id: cid, user_id: user.id }]) });
      return reply({ liked: true });
    }
    const commentDelete = path.match(/^\/api\/comments\/([0-9a-f-]{36})$/i);
    if (req.method === "DELETE" && commentDelete) {
      // O RLS só permite apagar o próprio comentário ou comentários nas próprias publicações.
      const removed = await api(`comments?id=eq.${commentDelete[1]}`, token, { method: "DELETE", headers: { Prefer: "return=representation" } });
      return removed?.length ? reply({ ok: true }) : reply({ error: "Comentário não encontrado ou sem permissão." }, 404);
    }
    if ((req.method === "DELETE" && path === "/api/users/me") || (req.method === "POST" && path === "/api/users/me/delete")) {
      if (!SERVICE_KEY) return reply({ error: "Exclusão de conta não está configurada no servidor." }, 503);
      const profile = await me();
      if (String(body.confirmUsername || "").trim().toLowerCase() !== String(profile?.username || "").toLowerCase()) {
        return reply({ error: "Para excluir a conta, confirme digitando o seu nome de usuário." }, 400);
      }
      // 1) Arquivos primeiro; se falhar, aborta sem apagar nada.
      try { await purgeUserStorage(user.id); }
      catch (e) { console.error("Falha ao apagar arquivos da conta:", e instanceof Error ? e.message : e); return reply({ error: "Não foi possível apagar seus arquivos agora. Nada foi excluído; tente novamente." }, 502); }
      // 2) Remove o usuário no Auth; profiles, posts, comentários, curtidas, mensagens etc. caem em cascata.
      const del = await serviceFetch(`/auth/v1/admin/users/${user.id}`, { method: "DELETE" });
      if (!del.ok) { console.error("Falha ao excluir usuário no Auth:", del.status); return reply({ error: "Não foi possível excluir a conta agora. Tente novamente." }, 502); }
      return reply({ ok: true });
    }
    if (req.method === "POST" && path === "/api/files/upload-url") {
      const category = String(body.category || "");
      const contentType = String(body.contentType || "").toLowerCase();
      const sizeBytes = Number(body.sizeBytes);
      if (!["avatar", "cover", "cover_original", "post_media"].includes(category)) return reply({ error: "Categoria de arquivo inválida." }, 400);
      const imageTypes = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
      const videoTypes = new Set(["video/mp4", "video/quicktime", "video/webm"]);
      const allowed = category === "post_media" ? (imageTypes.has(contentType) || videoTypes.has(contentType)) : imageTypes.has(contentType);
      const maxBytes = category === "post_media" && contentType.startsWith("video/") ? 100 * 1024 * 1024 : 25 * 1024 * 1024;
      if (!allowed) return reply({ error: "Tipo de arquivo não permitido para esta categoria." }, 415);
      if (!Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || sizeBytes > maxBytes) return reply({ error: `Arquivo inválido ou maior que ${Math.floor(maxBytes / 1024 / 1024)} MB.` }, 413);
      const name = String(body.fileName || "file").replace(/[^a-zA-Z0-9._-]/g, "_").slice(-100);
      const objectPath = `${user.id}/${category}/${crypto.randomUUID()}-${name}`;
      return reply({ file: { id: objectPath, category, contentType, sizeBytes }, uploadUrl: `${SUPABASE_URL}/storage/v1/object/post-media/${objectPath}`, objectPath, method: "PUT", requiredHeaders: { "Content-Type": contentType }, expiresInSeconds: null }, 201);
    }
        const fileComplete = path.match(/^\/api\/files\/(.+)\/complete$/);
    if (req.method === "POST" && fileComplete) {
      const objectPath = decodeURIComponent(fileComplete[1]);
      if (!safeObjectPath(objectPath) || !objectPath.startsWith(`${user.id}/`)) return reply({ error: "Arquivo inválido para esta conta." }, 403);
      const parts = objectPath.split("/");
      if (parts.length < 3 || !["avatar", "cover", "cover_original", "post_media"].includes(parts[1])) return reply({ error: "Caminho de mídia inválido." }, 400);
      const info = await getStoredObjectInfo(objectPath, token);
      if (!info) return reply({ error: "O arquivo ainda não foi enviado à nuvem ou não pode ser acessado. Tente enviar novamente." }, 422);
      const mime = objectMimeType(info, objectPath);
      if ((parts[1] === "avatar" || parts[1] === "cover" || parts[1] === "cover_original") && !mime.startsWith("image/")) return reply({ error: "Foto de perfil/capa precisa ser uma imagem." }, 415);
      if (parts[1] === "post_media" && !(mime.startsWith("image/") || mime.startsWith("video/"))) return reply({ error: "A publicação precisa conter uma imagem ou vídeo." }, 415);
      return reply({ ok: true, fileId: objectPath, status: "ready" });
    }
        const profileMedia = path.match(/^\/api\/users\/me\/(avatar|cover|cover_original)$/);
    if (req.method === "PATCH" && profileMedia) {
      const category = profileMedia[1];
      // Uma única foto de perfil: "cover" e "avatar" gravam o mesmo arquivo nas duas colunas (nunca divergem).
      const columns: Record<string, string[]> = { cover: ["cover_path", "avatar_path"], avatar: ["cover_path", "avatar_path"], cover_original: ["cover_original_path"] };
      const patch: Record<string, string> = { updated_at: new Date().toISOString() };
      for (const column of columns[category]) patch[column] = objectPath;
      const objectPath = String(body.fileId || "");
      if (!safeObjectPath(objectPath) || !objectPath.startsWith(`${user.id}/${category}/`)) return reply({ error: "Arquivo inválido para esta conta." }, 403);
      const info = await getStoredObjectInfo(objectPath, token);
      if (!info || !objectMimeType(info, objectPath).startsWith("image/")) return reply({ error: "A imagem não foi encontrada ou não passou na validação. Envie novamente." }, 422);
      const rows = await api(`profiles?id=eq.${user.id}&select=*`, token, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(patch) });
      return reply({ user: profileDto({ ...rows?.[0], email: user.email }) });
    }
        if (req.method==="GET" && path==="/api/posts") {
      const posts=await api("posts?select=*,profiles(id,username,display_name,avatar_path,cover_path)&visibility=eq.public&order=created_at.desc&limit=30",token);
      return reply({posts:await Promise.all((posts||[]).map(async (p:any)=>({id:p.id,createdAt:p.created_at,caption:p.caption,mediaUrl:p.media_path?.startsWith("http")?p.media_path:(p.media_path?`${SUPABASE_URL}/storage/v1/object/public/post-media/${p.media_path}`:""),mediaType:p.media_type,author:{id:p.profiles?.id,username:p.profiles?.username,displayName:p.profiles?.display_name},likes:0,comments:0})))});
    }
    if (req.method==="POST" && path==="/api/posts") {
      const caption = String(body.caption || "").trim();
      const mediaType = String(body.mediaType || "text");
      const mediaFileId = String(body.mediaFileId || "");
      if (caption.length > 5000) return reply({ error: "A legenda deve ter no máximo 5000 caracteres." }, 400);
      if (!["text", "image", "video"].includes(mediaType)) return reply({ error: "Tipo de publicação inválido." }, 400);
      let mediaPath: string | null = null;
      if (mediaType === "text") {
        if (mediaFileId) return reply({ error: "Publicação de texto não deve conter arquivo." }, 400);
      } else {
        if (!safeObjectPath(mediaFileId) || !mediaFileId.startsWith(`${user.id}/post_media/`)) return reply({ error: "A mídia precisa pertencer à sua conta." }, 403);
        const info = await getStoredObjectInfo(mediaFileId, token);
        const mime = objectMimeType(info, mediaFileId);
        if (!info || !(mediaType === "image" ? mime.startsWith("image/") : mime.startsWith("video/"))) return reply({ error: "A mídia não foi enviada corretamente à nuvem. Envie novamente antes de publicar." }, 422);
        mediaPath = mediaFileId;
      }
      const row = { user_id: user.id, caption, media_type: mediaType, media_path: mediaPath, visibility: "public" };
      const rows = await api("posts?select=*", token, { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify([row]) });
      if (rows?.[0]?.id) await notifyMentions(caption, rows[0].id);
      return reply({ post: rows?.[0] }, 201);
    }
    if(req.method==="GET"&&path==="/api/me/saved"){
      const saved=await api(`post_saves?user_id=eq.${user.id}&select=post_id,created_at&order=created_at.desc&limit=100`,token);
      const savedIds=(saved||[]).map((r:any)=>r.post_id);
      if(!savedIds.length)return reply({posts:[]});
      const rows=(await api(`posts?id=in.(${savedIds.join(",")})&visibility=eq.public&select=*,profiles!posts_user_id_fkey(id,username,display_name,avatar_path,cover_path)`,token))||[];
      const order=new Map<string,number>(savedIds.map((id:string,i:number)=>[id,i]));
      rows.sort((a:any,b:any)=>(order.get(a.id)||0)-(order.get(b.id)||0));
      return reply({posts:await buildPostDtos(rows,user,token)});
    }
    const postMatch=path.match(/^\/api\/posts\/([0-9a-f-]+)(?:\/(like|comments|save|repost|pin|archive))?$/i);
    if(postMatch){
      const id=postMatch[1], action=postMatch[2];
      if(req.method==="PATCH"&&!action){
        const caption=String(body.caption??"").trim();
        if(caption.length>5000)return reply({error:"A legenda deve ter no máximo 5000 caracteres."},400);
        const current=(await api(`posts?id=eq.${id}&user_id=eq.${user.id}&select=id,media_type,media_path`,token))?.[0];
        if(!current)return reply({error:"Publicação não encontrada."},404);
        if(!caption&&!current.media_path)return reply({error:"Uma publicação só de texto não pode ficar vazia."},400);
        await api(`posts?id=eq.${id}&user_id=eq.${user.id}`,token,{method:"PATCH",body:JSON.stringify({caption})});
        return reply({ok:true,caption});
      }
      if(req.method==="DELETE"&&!action){await api(`posts?id=eq.${id}&user_id=eq.${user.id}`,token,{method:"DELETE"});return reply({ok:true});}
      if(action==="pin"&&req.method==="POST"){
        const mine=(await api(`posts?id=eq.${id}&user_id=eq.${user.id}&select=id,pinned_at,visibility`,token))?.[0];
        if(!mine)return reply({error:"Publicação não encontrada."},404);
        if(mine.pinned_at){await api(`posts?id=eq.${id}&user_id=eq.${user.id}`,token,{method:"PATCH",body:JSON.stringify({pinned_at:null})});return reply({pinned:false});}
        if(mine.visibility!=="public")return reply({error:"Só publicações visíveis podem ser fixadas."},400);
        const already=await api(`posts?user_id=eq.${user.id}&pinned_at=not.is.null&select=id`,token);
        if((already||[]).length>=3)return reply({error:"Você pode fixar até 3 publicações. Desafixe uma para fixar outra."},400);
        await api(`posts?id=eq.${id}&user_id=eq.${user.id}`,token,{method:"PATCH",body:JSON.stringify({pinned_at:new Date().toISOString()})});
        return reply({pinned:true});
      }
      if(action==="archive"&&req.method==="POST"){
        const mine=(await api(`posts?id=eq.${id}&user_id=eq.${user.id}&select=id,visibility`,token))?.[0];
        if(!mine)return reply({error:"Publicação não encontrada."},404);
        const archive=mine.visibility==="public";
        await api(`posts?id=eq.${id}&user_id=eq.${user.id}`,token,{method:"PATCH",body:JSON.stringify(archive?{visibility:"archived",pinned_at:null}:{visibility:"public"})});
        return reply({archived:archive});
      }
      if(action==="like"&&req.method==="POST"){
        const post=(await api(`posts?id=eq.${id}&select=id,user_id,visibility`,token))?.[0];
        if(!post||post.visibility!=="public")return reply({error:"Publicação não encontrada."},404);
        const allowedReactions=["💚","🔥","😂","🤯","😢","👏"];
        const reaction=allowedReactions.includes(String(body.reaction||""))?String(body.reaction):"like";
        const existing=await api(`post_likes?post_id=eq.${id}&user_id=eq.${user.id}&select=user_id,reaction`,token).catch(()=>api(`post_likes?post_id=eq.${id}&user_id=eq.${user.id}&select=user_id`,token));
        if(existing?.length){
          const current=existing[0].reaction||"like";
          if(reaction==="like"||current===reaction){await api(`post_likes?post_id=eq.${id}&user_id=eq.${user.id}`,token,{method:"DELETE"});return reply({liked:false});}
          await api(`post_likes?post_id=eq.${id}&user_id=eq.${user.id}`,token,{method:"PATCH",body:JSON.stringify({reaction})});
          return reply({liked:true,reaction});
        }
        await api("post_likes",token,{method:"POST",body:JSON.stringify([reaction==="like"?{post_id:id,user_id:user.id}:{post_id:id,user_id:user.id,reaction}])});
        return reply({liked:true,reaction});
      }
      if((action==="save"||action==="repost")&&req.method==="POST"){
        const table=action==="save"?"post_saves":"post_reposts", flag=action==="save"?"saved":"reposted";
        const post=(await api(`posts?id=eq.${id}&select=id,user_id,visibility`,token))?.[0];
        if(!post||post.visibility!=="public")return reply({error:"Publicação não encontrada."},404);
        const existing=await api(`${table}?post_id=eq.${id}&user_id=eq.${user.id}&select=user_id`,token);
        if(existing?.length){await api(`${table}?post_id=eq.${id}&user_id=eq.${user.id}`,token,{method:"DELETE"});return reply({[flag]:false});}
        await api(table,token,{method:"POST",body:JSON.stringify([{post_id:id,user_id:user.id}])});return reply({[flag]:true});
      }
      if(action==="comments"&&req.method==="GET"){
        const rows=await api(`comments?post_id=eq.${id}&select=*,profiles(username,display_name)&order=created_at.asc`,token);
        return reply({comments:(rows||[]).map((c:any)=>({id:c.id,body:c.body,author:{username:c.profiles?.username,displayName:c.profiles?.display_name}}))});
      }
      if(action==="comments"&&req.method==="POST"){
        const text=String(body.body||"").trim();
        if(!text||text.length>2000)return reply({error:"O comentário precisa ter entre 1 e 2000 caracteres."},400);
        const post=(await api(`posts?id=eq.${id}&select=id,visibility`,token))?.[0];
        if(!post||post.visibility!=="public")return reply({error:"Publicação não encontrada."},404);
        let parentId:string|null=null, parentAuthor:string|null=null;
        const wantedParent=String(body.parentId||"");
        if(/^[0-9a-f-]{36}$/i.test(wantedParent)){
          const parent=(await api(`comments?id=eq.${wantedParent}&post_id=eq.${id}&select=id,user_id,parent_id`,token))?.[0];
          if(!parent)return reply({error:"O comentário que você quer responder não existe mais."},404);
          parentId=parent.parent_id||parent.id; // respostas ficam em um só nível
          parentAuthor=parent.user_id;
        }
        const insertRow:any={post_id:id,user_id:user.id,body:text};
        if(parentId)insertRow.parent_id=parentId;
        const rows=await api("comments?select=*",token,{method:"POST",headers:{Prefer:"return=representation"},body:JSON.stringify([insertRow])});
        await notifyMentions(text,id);
        if(parentAuthor)await notifyMentions("",id,"reply",[parentAuthor]);
        return reply({comment:rows?.[0]},201);
      }
    }
    if (req.method==="GET" && path.startsWith("/api/users/") && !path.includes("/me")) {
      const parts=path.split("/").filter(Boolean);
      const name=decodeURIComponent(parts[2]||"").replace(/^@/,"").toLowerCase();
      if(parts[3]==="followers"||parts[3]==="following"){
        const target=(await api(`profiles?username=eq.${encodeURIComponent(name)}&select=id`,token))?.[0];
        if(!target)return reply({users:[]});
        const follower=parts[3]==="followers";
        const links=await api(`follows?${follower?"following_id":"follower_id"}=eq.${target.id}&select=*`,token);
        const ids=(links||[]).map((x:any)=>follower?x.follower_id:x.following_id);
        const users=ids.length?await api(`profiles?id=in.(${ids.join(",")})&select=id,username,display_name,bio,avatar_path,cover_path,is_verified`,token):[];
        return reply({users:await withFollowFlag(users||[],user,token)});
      }
      if(parts[3]==="follow"&&req.method==="POST")return reply({error:"Rota inválida."},404);
      const rows=await api(`profiles?username=eq.${encodeURIComponent(name)}&select=*`,token);
      return rows?.[0]?reply({user:profileDto(rows[0])}):reply({error:"Perfil não encontrado."},404);
    }
    if(req.method==="GET"&&path==="/api/users/search"){
      const q=url.searchParams.get("q")||"";
      const rows=await api(`profiles?or=(username.ilike.*${encodeURIComponent(q)}*,display_name.ilike.*${encodeURIComponent(q)}*)&select=id,username,display_name,bio,avatar_path,cover_path,is_verified&limit=30`,token);
      return reply({users:(rows||[]).map((p:any)=>profileDto(p))});
    }
    if(req.method==="GET"&&path==="/api/notifications"){
      const rows=await api(`notifications?recipient_id=eq.${user.id}&select=*&order=created_at.desc&limit=100`,token);
      const actorIds=[...new Set((rows||[]).map((n:any)=>n.actor_id).filter(Boolean))];
      const actors=actorIds.length?await api(`profiles?id=in.(${actorIds.join(",")})&select=id,username,display_name,avatar_path,cover_path`,token):[];
      return reply({notifications:(rows||[]).map((n:any)=>{
        const p=(actors||[]).find((a:any)=>a.id===n.actor_id)||{};
        return {id:n.id,kind:n.kind,entityId:n.entity_id||"",createdAt:n.created_at,readAt:n.read_at||"",actor:{id:p.id||"",username:p.username||"",displayName:p.display_name||"",avatarUrl:p.avatar_path?(p.avatar_path.startsWith("http")?p.avatar_path:`${SUPABASE_URL}/storage/v1/object/public/post-media/${p.avatar_path}`):""}};
      })});
    }
    if(req.method==="POST"&&path==="/api/notifications/read"){
      await api(`notifications?recipient_id=eq.${user.id}&read_at=is.null`,token,{method:"PATCH",body:JSON.stringify({read_at:new Date().toISOString()})});return reply({ok:true});
    }
    if(req.method==="GET"&&path==="/api/inbox"){
      const rows=await api(`messages?or=(sender_id.eq.${user.id},recipient_id.eq.${user.id})&select=*&order=created_at.desc&limit=200`,token);
      const latest=new Map<string,any>();
      for(const m of rows||[]){const peer=m.sender_id===user.id?m.recipient_id:m.sender_id;if(!latest.has(peer))latest.set(peer,m);}
      const ids=[...latest.keys()];
      const profiles=ids.length?await api(`profiles?id=in.(${ids.join(",")})&select=id,username,display_name,avatar_path,cover_path`,token):[];
      const unread=await api(`messages?recipient_id=eq.${user.id}&read_at=is.null&select=sender_id`,token);
      const unreadCounts=new Map<string,number>();
      for(const m of unread||[])unreadCounts.set(m.sender_id,(unreadCounts.get(m.sender_id)||0)+1);
      return reply({conversations:[...latest.entries()].map(([id,m])=>{const p=(profiles||[]).find((x:any)=>x.id===id)||{};return {username:p.username,displayName:p.display_name,avatarUrl:p.avatar_path?(p.avatar_path.startsWith("http")?p.avatar_path:`${SUPABASE_URL}/storage/v1/object/public/post-media/${p.avatar_path}`):"",body:m.body,createdAt:m.created_at,unreadCount:unreadCounts.get(id)||0};})});
    }
    const msg=path.match(/^\/api\/messages\/([^/]+)$/);
    if(msg){
      const peerName=decodeURIComponent(msg[1]).replace(/^@/,"").toLowerCase();
      const peer=(await api(`profiles?username=eq.${encodeURIComponent(peerName)}&select=id`,token))?.[0];
      if(!peer)return reply({messages:[]});
      if(req.method==="GET"){
        await api(`messages?sender_id=eq.${peer.id}&recipient_id=eq.${user.id}&read_at=is.null`,token,{method:"PATCH",body:JSON.stringify({read_at:new Date().toISOString()})});
        const rows=await api(`messages?or=(and(sender_id.eq.${user.id},recipient_id.eq.${peer.id}),and(sender_id.eq.${peer.id},recipient_id.eq.${user.id}))&select=*&order=created_at.asc&limit=500`,token);
        return reply({messages:(rows||[]).map((m:any)=>({id:m.id,body:m.body,senderId:m.sender_id,createdAt:m.created_at}))});
      }
      if(req.method==="POST"){
        const text=String(body.body||"").trim();
        if(!text||text.length>10000)return reply({error:"A mensagem precisa ter entre 1 e 10000 caracteres."},400);
        if(peer.id===user.id)return reply({error:"Você não pode enviar mensagem para sua própria conta."},400);
        const rows=await api("messages?select=*",token,{method:"POST",headers:{Prefer:"return=representation"},body:JSON.stringify([{sender_id:user.id,recipient_id:peer.id,body:text}])});
        return reply({message:rows?.[0]},201);
      }
    }
    if(req.method==="GET"&&path==="/api/users/me/export")return reply({error:"Exportação ainda indisponível nesta API migrada."},501);
    return reply({error:"Rota ainda não implementada no gateway Supabase.",path},404);
  } catch (e) {
    const detail = e instanceof Error ? e.message : String(e);
    console.error("QINBLY Supabase gateway:", detail);
    // Return the actual Supabase/PostgREST failure so the app can show the real reason.
    return reply({error: detail || "Erro desconhecido no gateway Supabase."},500);
  }
});
