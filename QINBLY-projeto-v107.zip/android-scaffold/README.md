# android-scaffold — arquivos de projeto que faltavam no zip

O zip original só trazia `app/build.gradle.kts` e os `.kt`. Para o Android Studio abrir e compilar, faltam os arquivos abaixo.
**Se o seu projeto original já tem esses arquivos, use os seus e ignore esta pasta.** Se não tem, copie o conteúdo para a raiz do projeto.

| Arquivo aqui | Vai para |
|---|---|
| `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties` | raiz do projeto |
| `app/src/main/AndroidManifest.xml` | `app/src/main/` |
| `app/src/main/res/values/*.xml`, `res/xml/*.xml` | `app/src/main/res/` |

## O que eu NÃO consigo criar (precisa vir do seu projeto original)
- `res/drawable/qinbly_frame_8778 … qinbly_frame_8804` (as imagens das molduras de perfil, citadas no código).
- Ícones do app (`res/mipmap-*/ic_launcher*`). O manifest abaixo usa o ícone padrão do Android até você colocar o seu.
- `gradle/wrapper/*` (o Android Studio recria ao abrir o projeto).
- Chave de assinatura (use as variáveis `QINBLY_KEYSTORE_*` já previstas no `app/build.gradle.kts`).
