# Padronização das ações (curtir, comentar, repostar, salvar, enviar, seguir)

## O que mudou
- **Um só conjunto de botões** (`QinblyPostActionBar`) em todas as telas: início, vídeo em tela cheia, perfil, perfil público e visualizadores. Mesma ordem (curtir, comentar, repostar, salvar, enviar), mesmo ícone de 24dp, mesmo contador, mesma área de toque.
- **Um só botão de seguir** (`QinblyFollowButton`): "Seguir" azul preenchido, "Seguindo" com contorno. Usado no feed, vídeo em tela cheia, perfil público (versão grande) e lista de seguidores/seguindo.
- **Estado compartilhado** (`QinblyEngagement`): curtir/seguir/salvar/repostar feitos em uma tela aparecem nas outras na hora. Curtir e seguir são otimistas e voltam atrás se o servidor falhar. A contagem de curtidas não duplica depois de recarregar o feed.
- Marcações de curtida/seguindo valem por conta (trocar de conta não herda as da anterior).
- Link de compartilhamento unificado: `https://qinbly.com/post/<id>` (antes havia `qinbly.com` e `qinbly.com`). **Ajuste `QINBLY_POST_LINK_BASE` para o seu domínio real.**
- Contadores falsos "0" ao lado de repostar, salvar e enviar foram removidos (não representavam nada).
- Perfil e perfil público agora usam o diálogo de compartilhar do feed (enviar por mensagem/copiar link) em vez do compartilhamento de texto cru.

## Servidor
- A Edge Function `qinbly-api` agora devolve `likedByMe` e `isFollowing` por publicação e `followers/following/isFollowing` no perfil. **É preciso fazer o deploy de novo** para o coração e o "Seguindo" virem corretos após reabrir o app.

## Limites conhecidos
- **Repostar e salvar ainda são locais** (neste aparelho). Para virar rede social de verdade, precisam de tabela e rotas no servidor (contagem de reposts, aba "Salvos" sincronizada).
- Nada disto foi compilado nem testado em aparelho; foi conferido por leitura e balanceamento de chaves.

## Rodada 2: visualizador, card, comentários, salvar/repostar, links

- **Visualizador único** (`QinblyPostViewer`): é a tela cheia do Início (botões laterais, menu "mais", barra azul do vídeo, seguir, legenda). Agora também abre as publicações do Perfil e do Perfil público, para fotos e vídeos (fotos com galeria e toque duplo para curtir). A tela de foto de perfil continua separada, pois não é uma publicação.
- **Card de publicação único** (`QinblyPostCard`): o card do feed foi extraído e é usado no Início e nas abas Publicações/Vídeos dos dois Perfis (mesmo cabeçalho, menu, mídia, enquete, legenda e barra de ações). A aba "Fotos" continua em grade de miniaturas (padrão de rede social) e abre o mesmo visualizador.
- **Comentários únicos** (`QinblyCommentsDialog`): mesma tela, campo, emojis e teclado em todo lugar. Carrega, envia e exclui sozinho (botão de lixeira em comentários seus ou em publicações suas) e atualiza o número do botão sem recarregar o feed inteiro. Corrige também o comentário aberto a partir da tela cheia, que não carregava a lista.
- **Salvar e repostar no servidor:** novas tabelas `post_saves` e `post_reposts` (`SUPABASE/04_saves_reposts.sql`), rotas `POST /api/posts/:id/save` e `/repost`, e `savedByMe`, `repostedByMe` e `reposts` em cada publicação. O botão de repostar agora mostra o contador.
- **Link compartilhado abre a publicação:** nova rota `GET /api/posts/:id`; o app trata `https://qinbly.com/post/<id>` e `qinbly://post/<id>`, e mensagens com esse link ganham o botão "Abrir publicação".

## Para publicar
1. Rodar `SUPABASE/04_saves_reposts.sql` no SQL Editor.
2. `supabase functions deploy qinbly-api`.
3. Adicionar ao `AndroidManifest.xml` (não vem neste pacote), dentro da `MainActivity`, para links externos abrirem o app:

```xml
<intent-filter android:autoVerify="true">
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="https" android:host="qinbly.com" android:pathPrefix="/post/" />
    <data android:scheme="qinbly" android:host="post" />
</intent-filter>
```
(Para o link `https` abrir direto no app, o domínio também precisa publicar `/.well-known/assetlinks.json`.)

## Ainda sem teste real
Nada foi compilado nem executado em Android. Compile no Android Studio e valide: curtir/seguir/salvar/repostar entre telas e após fechar e reabrir o app, comentários, vídeo/foto nos três visualizadores e compartilhamento por mensagem.

## Rodada 3

- **Enquetes nos perfis:** votar agora recarrega o perfil (`reloadKey`) em `ProfilePage` e `PublicProfilePage`.
- **Foto de perfil:** um único `QinblyPhotoViewer` (zoom por pinça, toque duplo, controles, menu salvar/compartilhar e, no perfil público, denunciar) nos dois perfis. As telas de edição de perfil continuam separadas.
- **Meus salvos:** nova rota `GET /api/me/saved` (precisa publicar `qinbly-api` de novo), `QinblyApi.getSavedPosts` e a aba "Salvos" do seu perfil com os cards padrão. Ao remover o salvo, o item some da lista na hora.

## Rodada 4 — cara de rede social

- **Hashtags e menções:** `#tag` e `@usuario` nas legendas viram links (`QinblyRichText`). Hashtag abre a tela da tag (`QinblyTagHost`) com os cards padrão; menção abre o perfil.
- **Explorar:** a busca agora mostra "Em alta" (hashtags mais usadas) e "Pessoas para seguir" quando está vazia; digitar `#algo` abre a hashtag.
- **Feed:** o filtro "Tendências" agora ordena por engajamento (antes não fazia nada). "Perto de mim" foi removido porque não existe localização no app.
- **Recuperar senha:** link "Esqueci minha senha" na tela de login, via `POST /api/auth/forgot` (o e-mail é enviado pelo Supabase Auth).
- **Servidor novo:** `/api/hashtags/trending`, `/api/hashtags/:tag`, `/api/users/suggested`, `/api/auth/forgot` — é preciso publicar `qinbly-api` de novo.
- **Para o e-mail de recuperação funcionar:** configure em Supabase → Authentication → URL Configuration a URL de redirecionamento e o template do e-mail.
