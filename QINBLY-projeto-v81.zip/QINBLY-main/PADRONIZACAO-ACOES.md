# Padronização das ações (curtir, comentar, repostar, salvar, enviar, seguir)

## O que mudou
- **Um só conjunto de botões** (`QinblyPostActionBar`) em todas as telas: início, vídeo em tela cheia, perfil, perfil público e visualizadores. Mesma ordem (curtir, comentar, repostar, salvar, enviar), mesmo ícone de 24dp, mesmo contador, mesma área de toque.
- **Um só botão de seguir** (`QinblyFollowButton`): "Seguir" azul preenchido, "Seguindo" com contorno. Usado no feed, vídeo em tela cheia, perfil público (versão grande) e lista de seguidores/seguindo.
- **Estado compartilhado** (`QinblyEngagement`): curtir/seguir/salvar/repostar feitos em uma tela aparecem nas outras na hora. Curtir e seguir são otimistas e voltam atrás se o servidor falhar. A contagem de curtidas não duplica depois de recarregar o feed.
- Marcações de curtida/seguindo valem por conta (trocar de conta não herda as da anterior).
- Link de compartilhamento unificado: `https://qinbly.com/post/<id>` (antes havia `qinbly.com` e `qinbly.com`). **Ajuste `QINBLY_POST_LINK_BASE` para o seu domínio real.**
- Contadores falsos "0" ao lado de repostar, salvar e enviar foram removidos (não representavam nada).
- Perfil e perfil público agora usam o diálogo de compartilhar do feed (enviar por mensagem/copiar link) em vez do compartilhamento de texto cru.

## Servidor
- A Edge Function `qinbly-api` agora devolve `likedByMe` e `isFollowing` por publicação e `followers/following/isFollowing` no perfil. **É preciso fazer o deploy de novo** para o coração e o "Seguindo" virem corretos após reabrir o app.

## Limites conhecidos
- **Repostar e salvar ainda são locais** (neste aparelho). Para virar rede social de verdade, precisam de tabela e rotas no servidor (contagem de reposts, aba "Salvos" sincronizada).
- Nada disto foi compilado nem testado em aparelho; foi conferido por leitura e balanceamento de chaves.

## Rodada 2: visualizador, card, comentários, salvar/repostar, links

- **Visualizador único** (`QinblyPostViewer`): é a tela cheia do Início (botões laterais, menu "mais", barra azul do vídeo, seguir, legenda). Agora também abre as publicações do Perfil e do Perfil público, para fotos e vídeos (fotos com galeria e toque duplo para curtir). A tela de foto de perfil continua separada, pois não é uma publicação.
- **Card de publicação único** (`QinblyPostCard`): o card do feed foi extraído e é usado no Início e nas abas Publicações/Vídeos dos dois Perfis (mesmo cabeçalho, menu, mídia, enquete, legenda e barra de ações). A aba "Fotos" continua em grade de miniaturas (padrão de rede social) e abre o mesmo visualizador.
- **Comentários únicos** (`QinblyCommentsDialog`): mesma tela, campo, emojis e teclado em todo lugar. Carrega, envia e exclui sozinho (botão de lixeira em comentários seus ou em publicações suas) e atualiza o número do botão sem recarregar o feed inteiro. Corrige também o comentário aberto a partir da tela cheia, que não carregava a lista.
- **Salvar e repostar no servidor:** novas tabelas `post_saves` e `post_reposts` (`SUPABASE/04_saves_reposts.sql`), rotas `POST /api/posts/:id/save` e `/repost`, e `savedByMe`, `repostedByMe` e `reposts` em cada publicação. O botão de repostar agora mostra o contador.
- **Link compartilhado abre a publicação:** nova rota `GET /api/posts/:id`; o app trata `https://qinbly.com/post/<id>` e `qinbly://post/<id>`, e mensagens com esse link ganham o botão "Abrir publicação".

## Para publicar
1. Rodar `SUPABASE/04_saves_reposts.sql` no SQL Editor.
2. `supabase functions deploy qinbly-api`.
3. Adicionar ao `AndroidManifest.xml` (não vem neste pacote), dentro da `MainActivity`, para links externos abrirem o app:

```xml
<intent-filter android:autoVerify="true">
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="https" android:host="qinbly.com" android:pathPrefix="/post/" />
    <data android:scheme="qinbly" android:host="post" />
</intent-filter>
```
(Para o link `https` abrir direto no app, o domínio também precisa publicar `/.well-known/assetlinks.json`.)

## Ainda sem teste real
Nada foi compilado nem executado em Android. Compile no Android Studio e valide: curtir/seguir/salvar/repostar entre telas e após fechar e reabrir o app, comentários, vídeo/foto nos três visualizadores e compartilhamento por mensagem.

## Rodada 3

- **Enquetes nos perfis:** votar agora recarrega o perfil (`reloadKey`) em `ProfilePage` e `PublicProfilePage`.
- **Foto de perfil:** um único `QinblyPhotoViewer` (zoom por pinça, toque duplo, controles, menu salvar/compartilhar e, no perfil público, denunciar) nos dois perfis. As telas de edição de perfil continuam separadas.
- **Meus salvos:** nova rota `GET /api/me/saved` (precisa publicar `qinbly-api` de novo), `QinblyApi.getSavedPosts` e a aba "Salvos" do seu perfil com os cards padrão. Ao remover o salvo, o item some da lista na hora.

## Rodada 4 — cara de rede social

- **Hashtags e menções:** `#tag` e `@usuario` nas legendas viram links (`QinblyRichText`). Hashtag abre a tela da tag (`QinblyTagHost`) com os cards padrão; menção abre o perfil.
- **Explorar:** a busca agora mostra "Em alta" (hashtags mais usadas) e "Pessoas para seguir" quando está vazia; digitar `#algo` abre a hashtag.
- **Feed:** o filtro "Tendências" agora ordena por engajamento (antes não fazia nada). "Perto de mim" foi removido porque não existe localização no app.
- **Recuperar senha:** link "Esqueci minha senha" na tela de login, via `POST /api/auth/forgot` (o e-mail é enviado pelo Supabase Auth).
- **Servidor novo:** `/api/hashtags/trending`, `/api/hashtags/:tag`, `/api/users/suggested`, `/api/auth/forgot` — é preciso publicar `qinbly-api` de novo.
- **Para o e-mail de recuperação funcionar:** configure em Supabase → Authentication → URL Configuration a URL de redirecionamento e o template do e-mail.

## Rodada 5 — varredura

- **Menu "⋮" unificado:** havia duas cópias idênticas do menu da publicação dentro de `QinblyPostCard`; agora é um só (`QinblyPostMenu`).
- **Dono da publicação:** Editar legenda (novo, `PATCH /api/posts/:id`), Copiar link (antes só aparecia para os outros) e Excluir com confirmação.
- **Servidor:** publicar `qinbly-api` de novo.

## Rodada 6 — recursos sociais adicionais

- **Comentários:** respostas em fio (um nível), curtir comentário com contador, "Respondendo a @…", horário real.
- **Reações:** removidas a pedido do dono; só existe o botão de curtir normal.
- **Fixar (até 3) e arquivar:** no menu ⋮ das suas publicações; fixadas ficam no topo do perfil com 📌; nova aba "Arquivo" (só você vê).
- **Menções e respostas notificam** (`mention`, `reply`). Notificações novas também aparecem como notificação do sistema (enquanto o app está aberto/em memória; push com o app fechado exige Firebase — veja abaixo).
- **Clipes:** novo filtro "Clipes" no feed abre os vídeos em tela cheia, um por vez, deslizando na vertical.
- **Servidor:** publicar `qinbly-api` e rodar `SUPABASE/05_social_features.sql`.
- **Projeto:** `SUPABASE/00_base_schema.sql` (só banco novo), `SUPABASE/README.md` e `android-scaffold/` (manifest, gradle, res). Faltam do projeto original: as 25 imagens `qinbly_frame_*` e os ícones.

### Push com o app fechado (não incluído)
Precisa de um projeto Firebase seu: `google-services.json`, dependência `firebase-messaging`, um serviço que receba o token, uma tabela `device_tokens` e a função enviando via FCM. Sem a sua conta Firebase não dá para criar de forma funcional.

## Rodada 7 — "Seguir/Seguindo" igual em todas as telas

- **Causa:** as listas de pessoas (busca, "Pessoas para seguir", seguidores/seguindo) não recebiam do servidor se você já segue a pessoa (assumiam "não"), e a lista do perfil público nem tinha botão.
- **Correção:** o servidor agora devolve `isFollowing` em busca, seguidores e seguindo; o app aprende esse estado de qualquer resposta do servidor (feed, hashtag, salvos, busca, listas, perfis) em `QinblyEngagement.learnFollows`, e todas as telas usam o mesmo botão (`QinblyFollowButton`) lendo o mesmo estado. As listas de seguidores/seguindo (do seu perfil e dos perfis públicos) agora mostram avatar e botão de seguir.
- Publicar `qinbly-api` de novo.

## Rodada 8 — vídeo no feed

- Removido o botão de tela cheia que ficava sobre o vídeo (tocar no vídeo, fora do botão de play, continua abrindo o visualizador).
- Laterais de vídeos verticais agora usam o próprio vídeo desfocado como fundo (Android 12+; abaixo disso fica fundo preto), sem a faixa cinza.
- Barra de progresso fina e botão de som enquanto o vídeo toca.

## Rodada 9 — perfil sem "piscar" ao trocar de aba

- O seu perfil guardava tudo só dentro da tela; ao sair e voltar, a tela recomeçava vazia (foto padrão, contadores zerados, carregando) até a rede responder.
- Agora o último perfil carregado fica em memória (`QinblyCache.own`) e um resumo (foto, capa, contadores, moldura) também no aparelho. Ao voltar para a aba, a tela já abre com tudo e só atualiza por trás. É apagado ao sair/trocar de conta.

## Rodada 10 — fotos de perfil sem atraso em TODAS as telas

- **Causa raiz:** `QiblyAccountAvatar` (usado no feed, comentários, listas, mensagens…) baixava o perfil completo da pessoa toda vez que aparecia e começava mostrando a silhueta; por isso a foto "aparecia depois".
- **Correção:** `QinblyAvatarCache` — cache único (memória reativa + aparelho) de foto e moldura. Qualquer tela já abre com a foto certa; o perfil só é buscado se o cache tiver mais de 10 min e uma vez por pessoa (não por cartão). Trocar a foto de perfil invalida o cache; sair/trocar de conta limpa tudo.
- **Mensagens:** a lista de conversas também fica em cache (`QinblyCache.inbox`) e abre na hora.
- **Removido:** conversas de demonstração falsas (Carol, Júlia, Marina, Ana) que apareciam na lista de mensagens.

## Rodada 11 — uma única foto de perfil em todo o app

- **Causa:** cada perfil tem duas imagens no banco (`avatar_path` e `cover_path`). O cabeçalho do perfil lia a de capa; publicações, listas, busca, mensagens e notificações liam a de avatar. Quando as duas divergiam (fotos antigas, ou um upload que falhou), apareciam fotos diferentes.
- **Correção (servidor, vale para todos os usuários):** `canonicalizePhotos` em `qinbly-api` — toda resposta que traz perfil passa a usar a foto enquadrada no editor (`cover_path`) também como avatar. Não é preciso migrar dados.
- **Ao trocar a foto:** o app descarta o cache de fotos e recarrega; outras pessoas passam a ver a nova foto em até ~10 minutos (validade do cache de avatar) ou ao reabrir o app.
- Publicar `qinbly-api` de novo.

## Rodada 12 — só uma foto de perfil (a do cabeçalho)

- O editor de foto deixou de enviar uma segunda imagem de avatar; o servidor grava a mesma foto em `cover_path` e `avatar_path` (nunca divergem) e continua devolvendo a foto do cabeçalho como avatar em todas as respostas.
- Rodar `SUPABASE/06_single_profile_photo.sql` uma vez: copia a foto do cabeçalho para onde as duas colunas estavam diferentes (corrige também a lista de bloqueados).
- Publicar `qinbly-api` de novo.

## Rodada 13 — altura máxima das fotos no feed

- Fotos no cartão agora têm altura máxima 4:5 (a mesma do vídeo). Fotos mais altas aparecem inteiras, sem cortar, com a própria foto desfocada nas laterais (Android 12+; abaixo disso, fundo preto). Os botões de curtir/comentar ficam sempre visíveis. Tocar na foto continua abrindo o visualizador com a foto em tamanho cheio.

## Rodada 14 — comunidades reais e limpeza do perfil
- Aba **Comunidades**: botão "Criar comunidade" (nome 3–40, descrição ≤300, ícone), listas Minhas/Em alta/Descobrir vindas do servidor, Entrar/Participando com atualização imediata, tela da comunidade com publicações dos membros, excluir publicação (autor ou dono) e excluir comunidade (dono).
- Removida a aba **Arquivo** do perfil e o item "Arquivar" do menu; publicações antes arquivadas voltam a aparecer.
- Para funcionar: rodar `SUPABASE/07_communities.sql` e publicar de novo a função `qinbly-api`.

## Rodada 15 — Editar publicação completo
- Menu da publicação: "Editar" (sem "Arquivar"). A janela edita legenda e também troca foto, troca vídeo ou remove a mídia (enquetes e publicações com várias fotos editam só a legenda).
- Servidor: `PATCH /api/posts/:id` aceita `mediaFileId` + `mediaType` (mesma validação da criação) ou `removeMedia`. Republicar `qinbly-api`.

## Rodada 16 — respostas de comentários recolhidas
- Respostas ficam escondidas; cada comentário com respostas mostra "Ver N respostas ▾" / "Ocultar respostas ▴" (azul) ao lado de "Responder".
- Responder a um comentário principal: sem marcação. Responder a uma resposta: começa com @nome, em azul e clicável.

## Rodada 17 — menu do comentário
- Lixeira removida; ficou só o coração. Segurar o comentário abre: Copiar, Editar comentário (próprio), Excluir (próprio ou dono da publicação), Ver perfil e Denunciar comentário (de outras pessoas).
- Rodar `SUPABASE/08_comment_edit.sql` e republicar `qinbly-api` (nova rota `PATCH /api/comments/:id`).

## Rodada 18 — nova tela de compartilhar
- "Enviar para": prévia da publicação (miniatura, autor, legenda), busca em formato de pílula, pessoas em grade com foto (cache global) e marca de seleção azul, campo de mensagem opcional, botão azul "Enviar", e atalhos redondos "Copiar link" e "Outros apps" quando ninguém está selecionado.

## Rodada 19 — tela de Mensagens
- Removido o filtro "Grupos". Adicionada busca "Buscar conversas", filtros em pílulas azuis (contador de não lidas em "Não lidas"), conversas com horário real, destaque azul e texto em negrito nas não lidas, avatar 60dp.

## Rodada 20 — visualizador de fotos limpo
- Ao abrir uma foto, só aparece a imagem e a seta de voltar (sem botões laterais, legenda, foto de perfil ou seguir). Salvar/compartilhar/denunciar ficam no menu ⋮ do canto superior direito. Vídeos continuam com os controles.

## Rodada 21 — molduras centralizadas
- `qinblyNormalizedFrame` agora centraliza a moldura pelo centro do "buraco" transparente (onde fica a foto) em vez da caixa que inclui flor/laço/coroa; se o buraco não for detectado, volta ao comportamento anterior (caixa total).

## Rodada 22 — notificações
- Sino do topo: ícone de contorno e contador azul com anel. Tela de notificações: foto de perfil real (cache global) com selo do tipo (curtida, seguidor, comentário, menção), nome em negrito, seções "Novas" e "Anteriores", destaque azul nas não lidas, "Marcar como lidas", filtros em pílulas azuis e tela vazia no azul do app.

## Rodada 23 — varredura geral
- Removidos botões sem função: filtro/atalho "Lives", "Live" no menu de criar e na câmera, "Adicionar som" e "Seu Momento" no editor, e itens de configuração "Seus pedidos", "Idioma", "Central de ajuda", "Qualidade de vídeo", "Downloads", "Contas bloqueadas" duplicado e a seção Lives.
- Chat: balões azul (você) e cinza (outra pessoa), separador de dia, agrupamento por remetente, rolagem até a última mensagem, seletor de emojis real, botão enviar azul; removidos câmera/foto/áudio que não faziam nada.

## Rodada 24 — perfis
- Números do perfil (próprio e de outras pessoas): Publicações, Seguindo e Seguidores em texto limpo (o ícone branco quase invisível saiu).
- Perfil de outras pessoas: topo mostra @usuário; removidas as abas vazias Republicações/Curtidas; menu ⋮ com Copiar @, Compartilhar perfil, Denunciar perfil (envia denúncia de verdade) e Bloquear perfil (com confirmação).

## Rodada 25 — limpeza geral de botões sem função
- Removidos 40 itens de Configurações que só mostravam "precisa ser conectada ao serviço", a categoria vazia "Atividade e histórico" e os botões de chamada de voz/vídeo do chat. Texto das opções de fonte agora legível em tema claro.
- Pendente de decisão: interruptores de Configurações (feed, câmera, mensagens, amigos, acessibilidade, moderação) só guardam a preferência no aparelho e ainda não alteram o comportamento do app.

## Rodada 26 — configurações que funcionam
- Removidas as categorias e interruptores que só guardavam a preferência sem efeito (Privacidade, Publicações, Mensagens, Amigos, Moderação, Conteúdo, Lives, reprodução automática, economia de dados etc.).
- Agora funcionam de verdade: Notificações (liga/desliga geral e por tipo: curtidas, comentários/menções, seguidores), Vídeos (iniciar sem som, repetir), Tela (tema escuro, fontes), Acessibilidade (Texto maior em todo o app, Reduzir animações das molduras), Dados e segurança (cache, baixar dados, contas bloqueadas, excluir conta).

## Rodada 27 — Visual moderno
- Nova publicação (mídia): prévia grande arredondada, legenda em cartão com contador, dica de #/@, linhas mortas (Marcar pessoas/Localização/Música/Público) removidas, botão Publicar azul.
- Texto/Enquete: cabeçalho com avatar, cartão de texto com contador, opções numeradas, duração em chips, botão pílula.
- Tela de sucesso: corrigido contraste (fundo claro, azul).
- Editar publicação: cartão de legenda com contador, botões em pílula, Salvar azul.
- Todos os diálogos: cantos 28dp e cor do tema.

## Rodada 28 — Nome do app em um só lugar
- `QinblyBrand.Name` (MainActivity.kt) é usado em todos os textos visíveis. Para renomear: troque esse valor e `app_name` em `android-scaffold/app/src/main/res/values/strings.xml`.
- Não mudam sozinhos: links (qinbly.com), pacote `app.qinbly.android`, nomes de classes.

## Rodada 29 — Cabeçalho do feed (opção A)
- Topo: nome do app + busca + sino; abas Descobrir/Seguindo logo abaixo; "1 online" removido.
- Filtros (pílulas menores, sem ícone): Para você, Vídeos, Fotos, Enquetes, Textos. Saíram Novidades/Tendências/Clipes.
- Nome centralizado na barra de cima (busca e sino continuam à direita).
- Filtros do feed (Para você, Vídeos, Fotos, Enquetes, Textos) removidos; cabeçalho só com nome, busca, sino e abas.
- Card da publicação: legenda acima da mídia. Barra inferior: botão Criar em círculo azul preenchido. Corrigido parâmetros duplicados em AlertDialog (shape/containerColor).

## Rodada 30 — Molduras removidas
- Removidos: botão "Molduras" do perfil, tela de escolha, desenho nas fotos (feed, perfil, perfil público), decoração do cabeçalho do perfil, configuração "Reduzir animações" e `QinblyApi.setProfileFrame`.
- O servidor (`/api/users/me/frame`) e a coluna no banco foram mantidos sem uso; podem ser apagados depois.

## Rodada 31 — Mídia preenche o card
- Vídeo do feed: `RESIZE_MODE_ZOOM` (sem faixas pretas); foto do feed e miniaturas do perfil: `ContentScale.Crop` (sem faixas). Visualizadores em tela cheia continuam mostrando a mídia inteira.

## Rodada 32 — Vídeos
- Vídeos do feed tocam sozinhos (sem som, em repetição); botão do alto-falante liga o som. O player é liberado quando o card sai da tela.
- Ao abrir um vídeo em tela cheia (feed, perfil, perfil público, hashtag), deslizar mostra só vídeos. Abrindo uma foto, a lista continua como antes.

## Rodada 33 — Separador do feed
- Faixa de 3 dp (cor `feedDividerColor`) entre as publicações do feed.

## Rodada 34 — Conversa (1ª etapa, visual)
- Título "Mensagens" some dentro da conversa; topo com seta de voltar, foto com anel azul e busca/menu.
- Balões mais compactos (cantos 18/4, texto 15sp); publicação compartilhada vira cartão (miniatura do cache do feed, autor, legenda, "Abrir publicação") em vez do link.
- Campo de mensagem preenchido sem borda, botão enviar 46dp.
- Ficam para a 2ª etapa (precisam de servidor): áudio, anexos, figurinhas, reações, "online agora"/"lida".

## Rodada 35 — Sem cartões nas publicações
- `QinblyPostCard` sem borda, sombra, cantos nem margem lateral; só a faixa de 3 dp ao final de cada publicação.

## Rodada 36 — Voltar da conversa
- Botão de voltar do celular, dentro de uma conversa, volta para a lista de mensagens (antes ia ao Início). Seta de voltar no topo da conversa já existia desde a v52.

## Rodada 37 — Pessoas para seguir nas Mensagens
- Lista de conversas termina com "Pessoas para seguir" (autores do feed que a pessoa ainda não segue; 5 e "Ver mais" até 20). Sem conversas, as sugestões ocupam a tela. Pílula "Solicitações" (sem função) removida.

## Rodada 38 — Início renovado
- Linha única de abas com ícone em cima: Descobrir (estrela de 4 pontas), Seguindo, Em alta, Vídeos, Lives e Perto de mim (as duas últimas mostram "em breve").
- Descobrir: saudação por horário, Pergunta do dia (gira por dia, abre texto com #perguntadodia) e Desafio da semana (gira por semana; toque abre a hashtag, Participar abre a câmera com a hashtag). Texto inicial vai por `QinblyComposeSeed`.
- Em alta: período (Hoje/Semana/Mês), assuntos em alta e ranking por curtidas+comentários+reposts; sem servidor.
- Listas de perguntas/desafios ficam em `qinblyDailyQuestions` e `qinblyWeeklyChallenges` (MainActivity.kt).

## Rodada 39 — Aba Lives (v57)
- A aba **Lives** do cabeçalho abre `QinblyLivesPage`: barra fina azul "Começar uma live" (aviso "em breve"), "Ao vivo agora" (estado vazio "Ninguém ao vivo agora.") e "Agendadas" (vazio).
- Card de live: tarja "AO VIVO" + espectadores. Sala `QinblyLiveRoom`: nome com coração vermelho + número de curtidas, bolinha vermelha ao lado dos espectadores, duplo toque curte, botões pequenos 📌/📊 (abrem e fecham), campo de comentário + presente + compartilhar (avisos "em breve").
- A lista de lives ainda é vazia: transmissão real exige serviço de vídeo + tabelas no servidor. Nada compilado/testado.

## Rodada 40 — Botão de som dos vídeos (v58)
- `InlineVideoPlayer`: o botão de som deixou de usar emoji 🔇/🔊; agora é uma bolinha de vidro translúcida (30dp, borda fina) com ícone VolumeOff/VolumeUp branco.

## Rodada 41 — Curtir com dois toques em todo o app (v59)
- Novo `QinblyHeartBurst` (coração vermelho que cresce e some no centro). Duplo toque curte (só curte, não descurte) na foto e no vídeo do feed (`QinblyPostCard`), nas fotos do visualizador (`QinblyViewerImages`) e nos vídeos do visualizador (`QinblyFullscreenVideo(onDoubleTap)`). Toque simples continua abrindo o visualizador / pausando.

## Rodada 42 — Volume do celular liga o som do vídeo (v60)
- `MainActivity.dispatchKeyEvent` conta toques em "aumentar volume" (`QinblyVolumeKey.upTicks`); `InlineVideoPlayer` mudo observa o contador e liga o som (`muted=false`, `volume=1f`). Funciona mesmo com o volume já no máximo.
- (v61) Vale para as duas teclas: aumentar **e** diminuir o volume ligam o som dos vídeos mudos.

## Rodada 43 — Barra de ações da publicação (v62)
- `QinblyPostActionBar` (horizontal): curtir, comentar, republicar e enviar agrupados à esquerda (espaço de 8dp entre botões, sem divisores) e só o salvar na ponta direita. A versão vertical (sobre o vídeo) não mudou.

## Rodada 44 — Seguir some depois de seguir (v63)
- Novo `QinblyCardFollow` no cabeçalho das publicações: ao tocar em Seguir aparece "Seguindo" por ~1,5 s e o botão some; quem já é seguido não mostra o botão. Se deixar de seguir em outro lugar, "Seguir" volta. Listas de sugestões e perfil continuam mostrando Seguir/Seguindo normalmente.

## Rodada 45 — Ícones da barra de status visíveis (v64)
- `MainActivity.setContent`: hora, bateria e sinal (barra de cima) e ícones da barra de baixo passam a ser escuros quando o fundo do app é claro e claros no tema escuro (`isAppearanceLightStatusBars/NavigationBars` conforme `QiblyTheme.background`). Antes ficavam brancos sobre fundo branco.

## Rodada 46 — Editar perfil + @usuário único (v65)
- Tela Editar perfil renovada: campos claros com contorno fino (sem fundo escuro/ícones/setinha), foto com câmera no meio e link "Alterar foto" embaixo (nome e @ saíram de baixo da foto), seção "SOBRE VOCÊ" com Nome, Nome de usuário, **Bio** (agora logo após o usuário, antes ficava no fim) e País; categorias em chips que se encaixam (`FlowRow`, sem emojis, contador "N de 5"). A coluna agora **rola** (antes bio e parte das categorias ficavam cortadas).
- @usuário único: o app checa a disponibilidade enquanto digita (`QinblyApi.isUsernameAvailable` → `GET /api/users/username-available?u=`), mostra "✓ disponível" ou "Esse nome de usuário já está em uso", e bloqueia o Salvar. O servidor também devolve 409 com a mesma mensagem se o banco recusar (a coluna já é UNIQUE).
- **É preciso reimplantar a função `qinbly-api`** (nova rota + tratamento do erro 409). Nome de exibição pode repetir (só o @usuário é único).

## Rodada 47 — Menu "Criar" (v66)
- O botão Criar agora abre uma folha de baixo (Dialog) com 4 cartões 2x2 — Texto, Galeria, Câmera, Enquete — cada um com ícone de linha azul (`QinblyCreateIcons`, desenhados em 24x24) sobre círculo azul clarinho. Tocar fora fecha. Substitui o Popup com bolhas e símbolos de texto (✎ ▣ ◎ ▤).

## Rodada 48 — Começar uma live (v67)
- "Começar uma live" abre `QinblyLiveHost`: **Antes de começar** (título, Todos/Seguidores, Comentários, Presentes, "Iniciar live") → contagem 3-2-1 → **No ar** (foto/curtidas, cronômetro, barra de baixo: comentário, virar câmera, microfone, pausa ⏸ e X vermelho que encerra com confirmação + resumo). Pausar mostra "Live pausada" + "Retomar".
- Bolinha vermelha: **removida** da sala de quem assiste; na tela de quem transmite fica vermelha ao vivo, **cinza ao pausar** e volta a acender ao retomar.
- É só interface: não há câmera nem transmissão real ainda (avisa "Prévia" ao entrar no ar). Depende do serviço de vídeo + servidor.

## Rodada 49 — Deslizar troca as abas de cima (v68)
- Removido o gesto global que trocava a barra de baixo (Início → Mensagens → Lives → Avisos → Perfil). A barra de baixo agora só muda por toque.
- No Início, deslizar para os lados troca as abas do cabeçalho na ordem Descobrir, Seguindo, Em alta, Vídeos, Lives, Perto de mim (a última mostra "em breve" e não muda). Carrosséis de fotos dentro das publicações continuam tendo prioridade no próprio deslize.

## Rodada 50 — Mensagens estilo TikTok (v69)
- Título "Mensagens" centralizado, lupa no canto direito (abre a busca de pessoas); barra "Buscar conversas" removida.
- No lugar da barra: faixa horizontal com **Criar** (sua foto + "+" azul; toque mostra "Notas e stories: em breve") e atalhos para as pessoas com quem você conversa. Sem anel de story: stories/notas com frase e música ainda dependem do servidor e de um catálogo de músicas licenciado.
- "Atividade" fica só no sino de notificações (a aba Mensagens já mostra somente conversas e "Pessoas para seguir").

## Rodada 51 — Notificações (v70)
- Ícone de três tracinhos no topo abre "Configurações das notificações" (folha de baixo): Silenciar tudo, Curtidas, Comentários e menções, Novos seguidores, Avisos do QINBLY. Usam as mesmas chaves já lidas pelo aviso do sistema (`setting_notifications`, `setting_notice_likes/comments/followers`) + nova `setting_notice_system`.
- Linhas "começou a seguir você" ganham o botão **Seguir de volta** (vira "Seguindo"); `QinblyFollowButton` ganhou `idleLabel`.
- Mostra as 5 primeiras notificações; o resto abre para baixo na barrinha "▾ Mais notificações (N)" / "▴ Mostrar menos".
- Nova seção **Seguir de volta** no fim ("Pessoas que seguem você e que você não segue ainda."): até 6 pessoas e "Ver todos (N)"; vem de `getConnections(seuUsuario, "followers")` sem quem você já segue (lista fixada ao abrir).
- (v71) Menções ganharam interruptor próprio ("Menções", chave `setting_notice_mentions`) nas configurações das notificações; "Comentários" agora cobre só comentários e respostas. O servidor já cria a notificação "mencionou você" quando alguém marca @usuário em publicação (legenda) ou comentário.

## Rodada 52 (v72) — Notificações e Mensagens em azul
- Sino maior (ícone 32dp, toque 48dp); contador azul (redondo 1 dígito, pílula 2+ dígitos, "99+"), borda da cor do fundo.
- Contador do sino zera ao abrir a tela de notificações (ids vistos em `notif_seen_ids`); as novas continuam com fundo azul claro até serem tocadas.
- Notificações novas: sem bolinha; fundo azul claro (12%) + hora azul; ao tocar vira branca. "Seguir de volta" segue azul.
- Menção: texto "em uma publicação"/"em um comentário" (servidor grava `mention_comment` para comentários, com fallback para `mention`); tocar abre a publicação (`QinblyDeepLink.postId`). **Requer redeploy de `qinbly-api`.**
- Mensagens: sem vermelho. Hora na linha do nome; bolinha azul com a quantidade na linha da mensagem; fundo azul claro e negrito nas novas; ao abrir a conversa vira branca e o contador da aba (azul, borda) diminui.

## Rodada 53 (v73) — Tema escuro azul-noite + Configurações reorganizadas
- Tema escuro: fundo #10151E, cartões #1A2230, campos/blocos #222C3D, bordas #2A3446, texto #F2F4F8, secundário #A9B5C8 (antes preto puro). Textos/ícones fixos em preto (e dialogs/folhas brancas) passaram a usar `QiblyTheme.text/card/soft/border`; comentários e `Muted` também seguem o tema. Telas de câmera/galeria seguem claras.
- Configurações: Conta (compartilhar perfil, contas bloqueadas, excluir conta); Notificações (Silenciar tudo, curtidas, comentários e respostas, menções, seguidores, avisos do app); Vídeos; Tela (tema + fontes, sob um só cabeçalho); Acessibilidade (texto maior + reduzir animações, ligado ao coração); Dados e armazenamento (limpar cache com tamanho, baixar dados); Convidar amigos (novo); Ajuda e suporte; Alternar contas; Sair.
- Removidos: seção morta "Gerenciamento de contas", "Dispositivos conectados", "Segurança e permissões", duplicatas entre Conta e Dados, variáveis sem uso. Ícones de configurações agora em azul (antes brancos, invisíveis no tema claro).

## Rodada 54 (v74) — Ícones das configurações
- Um ícone Material (Outlined, linha fina, azul, em quadradinho azul claro) para cada opção de Configurações: Conta, Notificações, Vídeos, Tela, Acessibilidade, Dados, Convidar amigos, Ajuda, Alternar contas, Sair; e cada opção interna (compartilhar, bloqueio, lixeira, sino cortado, coração, balão, @, pessoa+, megafone, volume mudo, repetir, lua, etiqueta, fonte, tamanho de texto, câmera lenta, vassoura, download, bandeira, info, atualização). Sem emojis. Requer material-icons-extended (já no projeto).

## Rodada 55 (v75) — Estilo C nos ícones das configurações
- Ícones só como símbolo (sem quadradinho/fundo), linha fina (Outlined, 27dp) na cor do texto do tema. Cada opção com símbolo próprio (Novos seguidores = GroupAdd; Modo escuro = Brightness4; Tela = lua).

## Rodada 56 (v76) — Economia de dados e status online
- Vídeos > "Economia de dados" (`setting_data_saver`): vídeos do feed só carregam ao tocar em play.
- Conta > "Mostrar que estou online" (`setting_activity_status`, padrão ligado): desligado, o app não envia presença e o contador de online some para a própria pessoa.
- Ficam para depois (dependem de servidor/serviços externos): conta privada (coluna + pedidos de seguir), live real (serviço de vídeo), stories/notas com música (catálogo licenciado), chat etapa 2, Perto de mim.

## Rodada 57 (v77) — Ícone padrão de figurinhas/emojis
- Novo `QinblyCreateIcons.sticker` (carinha com "+" no canto, linha fina). É o ícone padrão para qualquer botão de emojis/figurinhas: barra de mensagens e campo de comentários das publicações. Regra de padronização: todo novo lugar com emojis/figurinhas deve usar esse símbolo (nunca emoji como ícone).
- Painel de figurinhas, clipe de anexos, câmera e microfone nas mensagens/comunidade seguem aprovados em esboço, ainda não aplicados (dependem de servidor).

## Rodada 58 (v78) — Barra de mensagem, criar comunidade com foto, folha Criar mais alta
- Mensagens: carinha/figurinha (ícone padrão) agora à ESQUERDA dentro da caixa; à direita clipe (painel com Documento, Galeria, Áudio, Localização, Contato, Enquete) e câmera; botão azul vira microfone quando a caixa está vazia e "enviar" quando há texto. Anexos/câmera/áudio ainda mostram aviso ("chega junto com a atualização do servidor"): o envio depende do servidor.
- Criar comunidade: sem seletor de ícones/emoji; círculo para escolher foto (prévia local, upload depende do servidor), contador do nome (x/40), campos arredondados.
- Folha "Criar" (botão +): sobe com padding da barra de navegação + 56dp, para não ficar sob os botões do celular.

## Rodada 59 (v79) — Criar comunidade em tela inteira
- `QinblyCreateCommunityDialog` agora é uma tela inteira (opção B): topo "Nova comunidade" com voltar, foto grande (112dp, prévia local), campos NOME (x/40) e DESCRIÇÃO com textos de exemplo, aviso de comunidade aberta e botão azul grande "Criar comunidade" fixo embaixo (respeita barra de navegação e teclado).

## Rodada 60 (v80) — Comunidade estilo grupo de WhatsApp
- Lista de comunidades: círculo azul com a letra inicial do nome no lugar do emoji (`QinblyCommunityAvatar`; vira foto quando o servidor guardar fotos).
- Por dentro: topo com voltar, avatar, nome e membros (toque abre "Dados da comunidade"), menu ⋮ (Dados, Silenciar/Reativar avisos, Limpar conversa [só na tela, `community_cleared_<id>`], Denunciar comunidade, Sair/Excluir). Descrição fixada em barra; balões (outros à esquerda com nome colorido, seus à direita), separadores Hoje/Ontem/data, hora, excluir própria mensagem (dono exclui qualquer); atualização automática a cada 6 s.
- Barra de mensagem igual à das conversas (figurinha/emoji à esquerda; clipe e câmera à direita; microfone/enviar). Quem ainda não entrou vê "Entrar na comunidade".
- Dados da comunidade: avatar grande, membros, atalhos Silenciar/Compartilhar, descrição, dono + quem já falou, Sair/Excluir/Denunciar. Lista completa de membros, foto, anexos e áudio dependem do servidor.
- Denúncia usa `reportContent("community", id, motivo)`; se o servidor ainda não aceitar o tipo "community", mostra o erro.

## Rodada 61 (v81) — Figurinhas (stickers) no lugar dos emojis
- Regra de padronização: o botão com o ícone F abre SEMPRE o painel de figurinhas (`QinblyStickerPanel`: painel azul clarinho, grade de 4 colunas, primeiro quadrado "+" para criar). Não há mais teclado de emojis dentro do app (o celular já tem o do teclado).
- 12 figurinhas desenhadas em vetor (`QinblyStickers`: happy, heart, like, love, cool, meh, wow, cry, star, fire, ok, party). Uma figurinha viaja como texto `::sticker:ID::` e aparece grande em: conversas (balão), comunidades (balão) e comentários das publicações. Na lista de conversas aparece como "Figurinha". Tocar na figurinha envia na hora.
- Valendo em: Mensagens, Comunidade e Comentários. Criar figurinhas das pessoas (foto → figurinha) depende do servidor: o "+" mostra aviso por enquanto.
