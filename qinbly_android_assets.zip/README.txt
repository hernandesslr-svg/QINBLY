QINBLY: 10 molduras originais em drawable-nodpi.
Ordem: rosa_neon, azul_eletrico, realeza, galaxia, fogo, cristal, romantica, dourada, esmeralda, prateada.
Usar painterResource(R.drawable.qinbly_frame_<nome>) sobre a foto circular, ContentScale.Fit, mantendo proporcao quadrada.
