# Padronização das ações (curtir, comentar, repostar, salvar, enviar, seguir)

## O que mudou
- **Um só conjunto de botões** (`QinblyPostActionBar`) em todas as telas: início, vídeo em tela cheia, perfil, perfil público e visualizadores. Mesma ordem (curtir, comentar, repostar, salvar, enviar), mesmo ícone de 24dp, mesmo contador, mesma área de toque.
- **Um só botão de seguir** (`QinblyFollowButton`): "Seguir" azul preenchido, "Seguindo" com contorno. Usado no feed, vídeo em tela cheia, perfil público (versão grande) e lista de seguidores/seguindo.
- **Estado compartilhado** (`QinblyEngagement`): curtir/seguir/salvar/repostar feitos em uma tela aparecem nas outras na hora. Curtir e seguir são otimistas e voltam atrás se o servidor falhar. A contagem de curtidas não duplica depois de recarregar o feed.
- Marcações de curtida/seguindo valem por conta (trocar de conta não herda as da anterior).
- Link de compartilhamento unificado: `https://qinbly.com/post/<id>` (antes havia `qinbly.com` e `qinbly.com`). **Ajuste `QINBLY_POST_LINK_BASE` para o seu domínio real.**
- Contadores falsos "0" ao lado de repostar, salvar e enviar foram removidos (não representavam nada).
- Perfil e perfil público agora usam o diálogo de compartilhar do feed (enviar por mensagem/copiar link) em vez do compartilhamento de texto cru.

## Servidor
- A Edge Function `qinbly-api` agora devolve `likedByMe` e `isFollowing` por publicação e `followers/following/isFollowing` no perfil. **É preciso fazer o deploy de novo** para o coração e o "Seguindo" virem corretos após reabrir o app.

## Limites conhecidos
- **Repostar e salvar ainda são locais** (neste aparelho). Para virar rede social de verdade, precisam de tabela e rotas no servidor (contagem de reposts, aba "Salvos" sincronizada).
- Nada disto foi compilado nem testado em aparelho; foi conferido por leitura e balanceamento de chaves.

## Rodada 2: visualizador, card, comentários, salvar/repostar, links

- **Visualizador único** (`QinblyPostViewer`): é a tela cheia do Início (botões laterais, menu "mais", barra azul do vídeo, seguir, legenda). Agora também abre as publicações do Perfil e do Perfil público, para fotos e vídeos (fotos com galeria e toque duplo para curtir). A tela de foto de perfil continua separada, pois não é uma publicação.
- **Card de publicação único** (`QinblyPostCard`): o card do feed foi extraído e é usado no Início e nas abas Publicações/Vídeos dos dois Perfis (mesmo cabeçalho, menu, mídia, enquete, legenda e barra de ações). A aba "Fotos" continua em grade de miniaturas (padrão de rede social) e abre o mesmo visualizador.
- **Comentários únicos** (`QinblyCommentsDialog`): mesma tela, campo, emojis e teclado em todo lugar. Carrega, envia e exclui sozinho (botão de lixeira em comentários seus ou em publicações suas) e atualiza o número do botão sem recarregar o feed inteiro. Corrige também o comentário aberto a partir da tela cheia, que não carregava a lista.
- **Salvar e repostar no servidor:** novas tabelas `post_saves` e `post_reposts` (`SUPABASE/04_saves_reposts.sql`), rotas `POST /api/posts/:id/save` e `/repost`, e `savedByMe`, `repostedByMe` e `reposts` em cada publicação. O botão de repostar agora mostra o contador.
- **Link compartilhado abre a publicação:** nova rota `GET /api/posts/:id`; o app trata `https://qinbly.com/post/<id>` e `qinbly://post/<id>`, e mensagens com esse link ganham o botão "Abrir publicação".

## Para publicar
1. Rodar `SUPABASE/04_saves_reposts.sql` no SQL Editor.
2. `supabase functions deploy qinbly-api`.
3. Adicionar ao `AndroidManifest.xml` (não vem neste pacote), dentro da `MainActivity`, para links externos abrirem o app:

```xml
<intent-filter android:autoVerify="true">
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="https" android:host="qinbly.com" android:pathPrefix="/post/" />
    <data android:scheme="qinbly" android:host="post" />
</intent-filter>
```
(Para o link `https` abrir direto no app, o domínio também precisa publicar `/.well-known/assetlinks.json`.)

## Ainda sem teste real
Nada foi compilado nem executado em Android. Compile no Android Studio e valide: curtir/seguir/salvar/repostar entre telas e após fechar e reabrir o app, comentários, vídeo/foto nos três visualizadores e compartilhamento por mensagem.

## Rodada 3

- **Enquetes nos perfis:** votar agora recarrega o perfil (`reloadKey`) em `ProfilePage` e `PublicProfilePage`.
- **Foto de perfil:** um único `QinblyPhotoViewer` (zoom por pinça, toque duplo, controles, menu salvar/compartilhar e, no perfil público, denunciar) nos dois perfis. As telas de edição de perfil continuam separadas.
- **Meus salvos:** nova rota `GET /api/me/saved` (precisa publicar `qinbly-api` de novo), `QinblyApi.getSavedPosts` e a aba "Salvos" do seu perfil com os cards padrão. Ao remover o salvo, o item some da lista na hora.

## Rodada 4 — cara de rede social

- **Hashtags e menções:** `#tag` e `@usuario` nas legendas viram links (`QinblyRichText`). Hashtag abre a tela da tag (`QinblyTagHost`) com os cards padrão; menção abre o perfil.
- **Explorar:** a busca agora mostra "Em alta" (hashtags mais usadas) e "Pessoas para seguir" quando está vazia; digitar `#algo` abre a hashtag.
- **Feed:** o filtro "Tendências" agora ordena por engajamento (antes não fazia nada). "Perto de mim" foi removido porque não existe localização no app.
- **Recuperar senha:** link "Esqueci minha senha" na tela de login, via `POST /api/auth/forgot` (o e-mail é enviado pelo Supabase Auth).
- **Servidor novo:** `/api/hashtags/trending`, `/api/hashtags/:tag`, `/api/users/suggested`, `/api/auth/forgot` — é preciso publicar `qinbly-api` de novo.
- **Para o e-mail de recuperação funcionar:** configure em Supabase → Authentication → URL Configuration a URL de redirecionamento e o template do e-mail.

## Rodada 5 — varredura

- **Menu "⋮" unificado:** havia duas cópias idênticas do menu da publicação dentro de `QinblyPostCard`; agora é um só (`QinblyPostMenu`).
- **Dono da publicação:** Editar legenda (novo, `PATCH /api/posts/:id`), Copiar link (antes só aparecia para os outros) e Excluir com confirmação.
- **Servidor:** publicar `qinbly-api` de novo.

## Rodada 6 — recursos sociais adicionais

- **Comentários:** respostas em fio (um nível), curtir comentário com contador, "Respondendo a @…", horário real.
- **Reações:** removidas a pedido do dono; só existe o botão de curtir normal.
- **Fixar (até 3) e arquivar:** no menu ⋮ das suas publicações; fixadas ficam no topo do perfil com 📌; nova aba "Arquivo" (só você vê).
- **Menções e respostas notificam** (`mention`, `reply`). Notificações novas também aparecem como notificação do sistema (enquanto o app está aberto/em memória; push com o app fechado exige Firebase — veja abaixo).
- **Clipes:** novo filtro "Clipes" no feed abre os vídeos em tela cheia, um por vez, deslizando na vertical.
- **Servidor:** publicar `qinbly-api` e rodar `SUPABASE/05_social_features.sql`.
- **Projeto:** `SUPABASE/00_base_schema.sql` (só banco novo), `SUPABASE/README.md` e `android-scaffold/` (manifest, gradle, res). Faltam do projeto original: as 25 imagens `qinbly_frame_*` e os ícones.

### Push com o app fechado (não incluído)
Precisa de um projeto Firebase seu: `google-services.json`, dependência `firebase-messaging`, um serviço que receba o token, uma tabela `device_tokens` e a função enviando via FCM. Sem a sua conta Firebase não dá para criar de forma funcional.

## Rodada 7 — "Seguir/Seguindo" igual em todas as telas

- **Causa:** as listas de pessoas (busca, "Pessoas para seguir", seguidores/seguindo) não recebiam do servidor se você já segue a pessoa (assumiam "não"), e a lista do perfil público nem tinha botão.
- **Correção:** o servidor agora devolve `isFollowing` em busca, seguidores e seguindo; o app aprende esse estado de qualquer resposta do servidor (feed, hashtag, salvos, busca, listas, perfis) em `QinblyEngagement.learnFollows`, e todas as telas usam o mesmo botão (`QinblyFollowButton`) lendo o mesmo estado. As listas de seguidores/seguindo (do seu perfil e dos perfis públicos) agora mostram avatar e botão de seguir.
- Publicar `qinbly-api` de novo.

## Rodada 8 — vídeo no feed

- Removido o botão de tela cheia que ficava sobre o vídeo (tocar no vídeo, fora do botão de play, continua abrindo o visualizador).
- Laterais de vídeos verticais agora usam o próprio vídeo desfocado como fundo (Android 12+; abaixo disso fica fundo preto), sem a faixa cinza.
- Barra de progresso fina e botão de som enquanto o vídeo toca.

## Rodada 9 — perfil sem "piscar" ao trocar de aba

- O seu perfil guardava tudo só dentro da tela; ao sair e voltar, a tela recomeçava vazia (foto padrão, contadores zerados, carregando) até a rede responder.
- Agora o último perfil carregado fica em memória (`QinblyCache.own`) e um resumo (foto, capa, contadores, moldura) também no aparelho. Ao voltar para a aba, a tela já abre com tudo e só atualiza por trás. É apagado ao sair/trocar de conta.

## Rodada 10 — fotos de perfil sem atraso em TODAS as telas

- **Causa raiz:** `QiblyAccountAvatar` (usado no feed, comentários, listas, mensagens…) baixava o perfil completo da pessoa toda vez que aparecia e começava mostrando a silhueta; por isso a foto "aparecia depois".
- **Correção:** `QinblyAvatarCache` — cache único (memória reativa + aparelho) de foto e moldura. Qualquer tela já abre com a foto certa; o perfil só é buscado se o cache tiver mais de 10 min e uma vez por pessoa (não por cartão). Trocar a foto de perfil invalida o cache; sair/trocar de conta limpa tudo.
- **Mensagens:** a lista de conversas também fica em cache (`QinblyCache.inbox`) e abre na hora.
- **Removido:** conversas de demonstração falsas (Carol, Júlia, Marina, Ana) que apareciam na lista de mensagens.

## Rodada 11 — uma única foto de perfil em todo o app

- **Causa:** cada perfil tem duas imagens no banco (`avatar_path` e `cover_path`). O cabeçalho do perfil lia a de capa; publicações, listas, busca, mensagens e notificações liam a de avatar. Quando as duas divergiam (fotos antigas, ou um upload que falhou), apareciam fotos diferentes.
- **Correção (servidor, vale para todos os usuários):** `canonicalizePhotos` em `qinbly-api` — toda resposta que traz perfil passa a usar a foto enquadrada no editor (`cover_path`) também como avatar. Não é preciso migrar dados.
- **Ao trocar a foto:** o app descarta o cache de fotos e recarrega; outras pessoas passam a ver a nova foto em até ~10 minutos (validade do cache de avatar) ou ao reabrir o app.
- Publicar `qinbly-api` de novo.

## Rodada 12 — só uma foto de perfil (a do cabeçalho)

- O editor de foto deixou de enviar uma segunda imagem de avatar; o servidor grava a mesma foto em `cover_path` e `avatar_path` (nunca divergem) e continua devolvendo a foto do cabeçalho como avatar em todas as respostas.
- Rodar `SUPABASE/06_single_profile_photo.sql` uma vez: copia a foto do cabeçalho para onde as duas colunas estavam diferentes (corrige também a lista de bloqueados).
- Publicar `qinbly-api` de novo.

## Rodada 13 — altura máxima das fotos no feed

- Fotos no cartão agora têm altura máxima 4:5 (a mesma do vídeo). Fotos mais altas aparecem inteiras, sem cortar, com a própria foto desfocada nas laterais (Android 12+; abaixo disso, fundo preto). Os botões de curtir/comentar ficam sempre visíveis. Tocar na foto continua abrindo o visualizador com a foto em tamanho cheio.

## Rodada 14 — comunidades reais e limpeza do perfil
- Aba **Comunidades**: botão "Criar comunidade" (nome 3–40, descrição ≤300, ícone), listas Minhas/Em alta/Descobrir vindas do servidor, Entrar/Participando com atualização imediata, tela da comunidade com publicações dos membros, excluir publicação (autor ou dono) e excluir comunidade (dono).
- Removida a aba **Arquivo** do perfil e o item "Arquivar" do menu; publicações antes arquivadas voltam a aparecer.
- Para funcionar: rodar `SUPABASE/07_communities.sql` e publicar de novo a função `qinbly-api`.

## Rodada 15 — Editar publicação completo
- Menu da publicação: "Editar" (sem "Arquivar"). A janela edita legenda e também troca foto, troca vídeo ou remove a mídia (enquetes e publicações com várias fotos editam só a legenda).
- Servidor: `PATCH /api/posts/:id` aceita `mediaFileId` + `mediaType` (mesma validação da criação) ou `removeMedia`. Republicar `qinbly-api`.

## Rodada 16 — respostas de comentários recolhidas
- Respostas ficam escondidas; cada comentário com respostas mostra "Ver N respostas ▾" / "Ocultar respostas ▴" (azul) ao lado de "Responder".
- Responder a um comentário principal: sem marcação. Responder a uma resposta: começa com @nome, em azul e clicável.

## Rodada 17 — menu do comentário
- Lixeira removida; ficou só o coração. Segurar o comentário abre: Copiar, Editar comentário (próprio), Excluir (próprio ou dono da publicação), Ver perfil e Denunciar comentário (de outras pessoas).
- Rodar `SUPABASE/08_comment_edit.sql` e republicar `qinbly-api` (nova rota `PATCH /api/comments/:id`).

## Rodada 18 — nova tela de compartilhar
- "Enviar para": prévia da publicação (miniatura, autor, legenda), busca em formato de pílula, pessoas em grade com foto (cache global) e marca de seleção azul, campo de mensagem opcional, botão azul "Enviar", e atalhos redondos "Copiar link" e "Outros apps" quando ninguém está selecionado.

## Rodada 19 — tela de Mensagens
- Removido o filtro "Grupos". Adicionada busca "Buscar conversas", filtros em pílulas azuis (contador de não lidas em "Não lidas"), conversas com horário real, destaque azul e texto em negrito nas não lidas, avatar 60dp.

## Rodada 20 — visualizador de fotos limpo
- Ao abrir uma foto, só aparece a imagem e a seta de voltar (sem botões laterais, legenda, foto de perfil ou seguir). Salvar/compartilhar/denunciar ficam no menu ⋮ do canto superior direito. Vídeos continuam com os controles.

## Rodada 21 — molduras centralizadas
- `qinblyNormalizedFrame` agora centraliza a moldura pelo centro do "buraco" transparente (onde fica a foto) em vez da caixa que inclui flor/laço/coroa; se o buraco não for detectado, volta ao comportamento anterior (caixa total).

## Rodada 22 — notificações
- Sino do topo: ícone de contorno e contador azul com anel. Tela de notificações: foto de perfil real (cache global) com selo do tipo (curtida, seguidor, comentário, menção), nome em negrito, seções "Novas" e "Anteriores", destaque azul nas não lidas, "Marcar como lidas", filtros em pílulas azuis e tela vazia no azul do app.

## Rodada 23 — varredura geral
- Removidos botões sem função: filtro/atalho "Lives", "Live" no menu de criar e na câmera, "Adicionar som" e "Seu Momento" no editor, e itens de configuração "Seus pedidos", "Idioma", "Central de ajuda", "Qualidade de vídeo", "Downloads", "Contas bloqueadas" duplicado e a seção Lives.
- Chat: balões azul (você) e cinza (outra pessoa), separador de dia, agrupamento por remetente, rolagem até a última mensagem, seletor de emojis real, botão enviar azul; removidos câmera/foto/áudio que não faziam nada.

## Rodada 24 — perfis
- Números do perfil (próprio e de outras pessoas): Publicações, Seguindo e Seguidores em texto limpo (o ícone branco quase invisível saiu).
- Perfil de outras pessoas: topo mostra @usuário; removidas as abas vazias Republicações/Curtidas; menu ⋮ com Copiar @, Compartilhar perfil, Denunciar perfil (envia denúncia de verdade) e Bloquear perfil (com confirmação).

## Rodada 25 — limpeza geral de botões sem função
- Removidos 40 itens de Configurações que só mostravam "precisa ser conectada ao serviço", a categoria vazia "Atividade e histórico" e os botões de chamada de voz/vídeo do chat. Texto das opções de fonte agora legível em tema claro.
- Pendente de decisão: interruptores de Configurações (feed, câmera, mensagens, amigos, acessibilidade, moderação) só guardam a preferência no aparelho e ainda não alteram o comportamento do app.

## Rodada 26 — configurações que funcionam
- Removidas as categorias e interruptores que só guardavam a preferência sem efeito (Privacidade, Publicações, Mensagens, Amigos, Moderação, Conteúdo, Lives, reprodução automática, economia de dados etc.).
- Agora funcionam de verdade: Notificações (liga/desliga geral e por tipo: curtidas, comentários/menções, seguidores), Vídeos (iniciar sem som, repetir), Tela (tema escuro, fontes), Acessibilidade (Texto maior em todo o app, Reduzir animações das molduras), Dados e segurança (cache, baixar dados, contas bloqueadas, excluir conta).

## Rodada 27 — Visual moderno
- Nova publicação (mídia): prévia grande arredondada, legenda em cartão com contador, dica de #/@, linhas mortas (Marcar pessoas/Localização/Música/Público) removidas, botão Publicar azul.
- Texto/Enquete: cabeçalho com avatar, cartão de texto com contador, opções numeradas, duração em chips, botão pílula.
- Tela de sucesso: corrigido contraste (fundo claro, azul).
- Editar publicação: cartão de legenda com contador, botões em pílula, Salvar azul.
- Todos os diálogos: cantos 28dp e cor do tema.

## Rodada 28 — Nome do app em um só lugar
- `QinblyBrand.Name` (MainActivity.kt) é usado em todos os textos visíveis. Para renomear: troque esse valor e `app_name` em `android-scaffold/app/src/main/res/values/strings.xml`.
- Não mudam sozinhos: links (qinbly.com), pacote `app.qinbly.android`, nomes de classes.

## Rodada 29 — Cabeçalho do feed (opção A)
- Topo: nome do app + busca + sino; abas Descobrir/Seguindo logo abaixo; "1 online" removido.
- Filtros (pílulas menores, sem ícone): Para você, Vídeos, Fotos, Enquetes, Textos. Saíram Novidades/Tendências/Clipes.
- Nome centralizado na barra de cima (busca e sino continuam à direita).
- Filtros do feed (Para você, Vídeos, Fotos, Enquetes, Textos) removidos; cabeçalho só com nome, busca, sino e abas.
- Card da publicação: legenda acima da mídia. Barra inferior: botão Criar em círculo azul preenchido. Corrigido parâmetros duplicados em AlertDialog (shape/containerColor).

## Rodada 30 — Molduras removidas
- Removidos: botão "Molduras" do perfil, tela de escolha, desenho nas fotos (feed, perfil, perfil público), decoração do cabeçalho do perfil, configuração "Reduzir animações" e `QinblyApi.setProfileFrame`.
- O servidor (`/api/users/me/frame`) e a coluna no banco foram mantidos sem uso; podem ser apagados depois.
